import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './Header'
import Footer from './Footer'

function App() {
  return (
    <>
    <Header headertitle="My App" bcolor="green" tcolor="white"/>
    <hr/>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet dolore magnam fugit, voluptas alias neque suscipit ratione ea! A beatae pariatur ab alias? Laboriosam nemo, impedit vel eos excepturi rerum?</p>
    <Footer bcolor="gray"/>
    </>

  )
}

export default App

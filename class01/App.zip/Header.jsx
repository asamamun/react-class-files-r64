const Header = ({headertitle, bcolor, tcolor}) => {
    // console.log("Header component rendered with props:", p);
    // This is a simple functional component that renders a header
    // It can be used to display a title or navigation for the application
    let title = headertitle || "My Application";
    return (
        <div style={{ backgroundColor: bcolor }} className="myheader">
            <h1 style={{ color: tcolor }}>{title}</h1>
        </div>
    );
};
/* function Header(){
    // This is a simple functional component that renders a header
    // It can be used to display a title or navigation for the application
    let title = "My Application";
    return(
        <div>
            <h1>{title}</h1>
        </div>
    )
} */

export default Header
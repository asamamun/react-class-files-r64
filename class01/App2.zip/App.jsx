import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'


function App() {
  const [products, setProducts] = useState([])

  fetch('https://dummyjson.com/products')
    .then(res => res.json())
    .then(data => setProducts(data.products))

  return (
    <div className="container">
      {products.map(product => (
        <div className="card" key={product.id}>
          <img src={product.images[0]} alt={product.title} />
          <div className="card-body">
            <h5 className="card-title">{product.title}</h5>
            <p className="card-text">${product.price}</p>
          </div>
        </div>
      ))}
    </div>
  )
  return (
    <div>
<h1>Hello React</h1>
</div>
  )
}

export default App

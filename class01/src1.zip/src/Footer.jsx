
const Footer = ({bcolor}) => {
    const year = new Date().getFullYear();
    const fb = {
        h: "https://www.facebook.com/myapp",
        t: "Our Facebook Link"
    };
    const twitter = {
        href: "https://twitter.com/myapp",
        text: "Our Twitter Link"
    };
    return (
        <footer className="footer" style={{ backgroundColor: bcolor }}>
            <p>© {year} My App. All rights reserved.</p>
            <p>
                Follow us on Facebook <a href={fb.h} target="_blank">{fb.t}</a> and 
                <a href={twitter.href} target="_blank" rel="noopener noreferrer">
                    {twitter.text}
                </a>
            </p>
        </footer>
    );
};

/* function Footer(){
    let year = new Date().getFullYear();
    let fb = {
        h: "https://www.facebook.com/myapp",
        t: "Our Facebook Link"
    };
    let twitter = {
        href: "https://twitter.com/myapp",
        text: "Our Twitter Link"
    };
    return (
        <footer className="footer">
        <p>© {year} My App. All rights reserved.</p>
        <p>
            Follow us on Facebook <a href={fb.h} target="_blank">{fb.t}</a> and 
            <a href={twitter.href} target="_blank" rel="noopener noreferrer">
                {twitter.text}
            </a>
        </p>
        </footer>
    );
} */

export default Footer
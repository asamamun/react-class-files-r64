import Logo from './assets/logo-removebg-preview.png'
const Header = (props) => {
    // console.log("Header component rendered with props:", p);
    // This is a simple functional component that renders a header
    // It can be used to display a title or navigation for the application
    let title = props.headertitle || "My Application";
    return (
        <div style={{ backgroundColor: props.bcolor }} className="myheader">
            <img src={Logo} alt="" />
            <h1 style={{ color: props.tcolor }}>{title}</h1>
        </div>
    );
};
/* function Header(){
    // This is a simple functional component that renders a header
    // It can be used to display a title or navigation for the application
    let title = "My Application";
    return(
        <div>
            <h1>{title}</h1>
        </div>
    )
} */

export default Header
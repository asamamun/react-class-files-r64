import './App.css'


function App() {
  let countryList = [
    { name: 'India', code: 'IN' },
    { name: 'United States', code: 'US' },
    { name: 'United Kingdom', code: 'GB' },
    { name: 'Canada', code: 'CA' },
    { name: 'Australia', code: 'AU' },
    { name: 'Germany', code: 'DE' },
    { name: 'France', code: 'FR' },
    { name: 'Japan', code: 'JP' },
    { name: 'China', code: 'CN' },
    { name: 'Brazil', code: 'BR' },
    { name: 'South Africa', code: 'ZA' },
    { name: 'Russia', code: 'RU' },
    { name: 'Italy', code: 'IT' },
    { name: 'Spain', code: 'ES' },
    { name: 'Mexico', code: 'MX' },
    { name: 'Netherlands', code: 'NL' },
    { name: 'Sweden', code: 'SE' },
    { name: 'Norway', code: 'NO' },
    { name: 'Finland', code: 'FI' },
    { name: 'Denmark', code: 'DK' },
    { name: 'Poland', code: 'PL' },
    { name: 'Turkey', code: 'TR' },
    { name: 'South Korea', code: 'KR' },
    { name: 'Argentina', code: 'AR' },
    { name: 'New Zealand', code: 'NZ' },
    { name: 'Singapore', code: 'SG' },
    { name: 'Malaysia', code: 'MY' },
    { name: 'Indonesia', code: 'ID' },
    { name: 'Philippines', code: 'PH' },
    { name: 'Thailand', code: 'TH' },
    { name: 'Vietnam', code: 'VN' }
  ];
  let colors = ['#FF5733', '#33FF57', '#3357FF', '#F1C40F', '#8E44AD', '#E74C3C', '#3498DB', '#2ECC71', '#9B59B6', '#F39C12'];
  return (
    <>
      <h3>Country List in Card</h3>
      { colors.map((color, index) => { return <span key={index} style={{ backgroundColor: color }}>{index} : {color}</span>} ) }
      <div className='countryContainer'>
        {countryList.map(({ name, code }, index) =>
          <div className='countryCard' key={index}>
            <h4>{name}</h4>
            <p>{code}</p>
          </div>
        )
        }
      </div>
    </>
  )

}

export default App

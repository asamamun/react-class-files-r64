import './App.css'
import Input from './Input';
import SalaryList from './SalaryList';


function App() {
  let countryList = [
    { name: 'India', code: 'IN' },
    { name: 'United States', code: 'US' },
    { name: 'United Kingdom', code: 'GB' },
    { name: 'Canada', code: 'CA' },
    { name: 'Australia', code: 'AU' },
    { name: 'Germany', code: 'DE' },
    { name: 'France', code: 'FR' },
    { name: 'Japan', code: 'JP' },
    { name: 'China', code: 'CN' },
    { name: 'Brazil', code: 'BR' },
    { name: 'South Africa', code: 'ZA' },
    { name: 'Russia', code: 'RU' },
    { name: 'Italy', code: 'IT' },
    { name: 'Spain', code: 'ES' },
    { name: 'Mexico', code: 'MX' },
    { name: 'Netherlands', code: 'NL' },
    { name: 'Sweden', code: 'SE' },
    { name: 'Norway', code: 'NO' },
    { name: 'Finland', code: 'FI' },
    { name: 'Denmark', code: 'DK' },
    { name: 'Poland', code: 'PL' },
    { name: 'Turkey', code: 'TR' },
    { name: 'South Korea', code: 'KR' },
    { name: 'Argentina', code: 'AR' },
    { name: 'New Zealand', code: 'NZ' },
    { name: 'Singapore', code: 'SG' },
    { name: 'Malaysia', code: 'MY' },
    { name: 'Indonesia', code: 'ID' },
    { name: 'Philippines', code: 'PH' },
    { name: 'Thailand', code: 'TH' },
    { name: 'Vietnam', code: 'VN' }
  ];
  let colors = ['#FF5733', '#33FF57', '#3357FF', '#F1C40F', '#8E44AD', '#E74C3C', '#3498DB', '#2ECC71', '#9B59B6', '#F39C12'];
  let salary = [{ name: "John", amount: 50000 },
                { name: "Jane", amount: 60000 },
                { name: "Doe", amount: 55000 }];
  return (
    <>
      <h3>Country List in Card</h3>
      { colors.map((color, index) =>  <span key={index} style={{ backgroundColor: color, padding: '10px', margin: '10px', display: 'inline-block' }}>{index} : {color}</span> ) }
      <div className='countryContainer'>
        {countryList.map((c, index) =>
          <div className='countryCard' key={index}>
            <h4>{c.name}</h4>
            <p>{c.code}</p>
          </div>
        )
        }
      </div>
      <h3>Salary List</h3>
      <div className='salaryContainer'>
        {/* <ul>
        {salary.map((emp,i) => <li key={i}>Employee Name: {emp.name} Salary: {emp.amount}, Total: {emp.amount * 2}</li> )}
        </ul> */}
        <SalaryList salaryArray={salary} />
      </div>
      <h1>Dynamic Input</h1>
      <Input t="number" ph="Enter Number" />
      <Input t="text" ph="Enter Text" />
      <Input t="password" ph />
      <Input t="color" ph="Enter Color" />
      <Input t="file" ph="Upload File" />
    </>
  )

}

export default App

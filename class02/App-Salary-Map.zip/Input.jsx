const Input = ({t,ph}) => <input type={t} placeholder={ph}/>
export default Input;
import Posts from "./Posts";
const App = () => {
  console.log("Posts:", Posts);
/*   fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error fetching data:', error)); */

  return (
    <div>
      <h1>Welcome to My App</h1>
      <ShowPosts posts={Posts} />
{/*       <ul>
        {Posts.map(post => (
          <li key={post.id}>
            <h2>{post.title}</h2>
            <p>{post.body}</p>
          </li>
        ))}
      </ul> */}
    </div>
  );
}
/* function App() {
  return (
    <div>
      <h1>Welcome to My App</h1>
      <p>This is a simple React application.</p>
    </div>
  );
} */
export default App;
import Posts from "./Posts";
import Search from "./Search";
import ShowPosts from "./ShowPosts";
const App = ({color}) => {
  // console.log("Posts:", Posts);
/*   fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error fetching data:', error)); */

  return (
    <div className="bg-info" style={{ 
      backgroundColor: color === "dark" ? "#333" : "#fff", 
      color: color === "dark" ? "#fff" : "#000" }}>
        <div className="d-flex justify-content-between">
          <h1>Welcome to My App</h1>
          <Search />
        </div>      
      <ShowPosts allposts={Posts} />
    </div>
  );
}
export default App;
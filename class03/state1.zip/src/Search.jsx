import React from 'react';
const Search = () => {
  const [searchTerm, setSearchTerm] = React.useState('bangladesh');
  //handleSubmit
  const handleSubmit = (event) => {
    event.preventDefault();
    // Implement search logic here
    console.log("Search submitted :", event.target.value);
    setSearchTerm(event.target.value);
    // You can also call a function to filter posts based on searchTerm
  };
  return (
    <div className="search-container">             
      <input type="text" value={searchTerm} placeholder="Search..." className="search-input form-control" onChange={handleSubmit} />      
    </div>
  );
};

export default Search;
/* const Search = () => {
  //handleSubmit
  const handleSubmit = (event) => {
    event.preventDefault();
    // Implement search logic here
    console.log("Search submitted");
  };
  return (
    <div className="search-container">
      <form onSubmit={handleSubmit} className="search-form">        
      <input type="text" placeholder="Search..." className="search-input form-control" />
      <button type="submit" className="btn btn-primary">Search</button>
      </form>
    </div>
  );
};

export default Search; */
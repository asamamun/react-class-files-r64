import SinglePost from "./SinglePost";
const ShowPosts = ({ allposts }) => (
    allposts.map((p) =>
        <div key={p.id}>
            <SinglePost post={p} />
            <hr />
        </div>
    )
)
export default ShowPosts;
/* import React from "react";
import SinglePost from "./SinglePost";
const ShowPosts = ({ allposts }) => (
    allposts.map((p) =>
        <React.Fragment key={p.id}>
            <SinglePost post={p} />
            <hr />
        </React.Fragment>
    )
)
export default ShowPosts; */
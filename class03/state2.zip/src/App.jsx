import React from "react";
import Posts from "./Posts";
import Search from "./Search";
import ShowPosts from "./ShowPosts";
const App = ({color}) => {
const [searchTerm, setSearchTerm] = React.useState('');
const handleSearch = (event) => {
setSearchTerm(event.target.value);
};
const searchedPosts = Posts.filter(function (story) {
return story.title.toLowerCase().includes(searchTerm.toLowerCase())

});


  return (
    <div className="bg-info" style={{ 
      backgroundColor: color === "dark" ? "#333" : "#fff", 
      color: color === "dark" ? "#fff" : "#000" }}>
        <div className="d-flex justify-content-between">
          <h1>Welcome to My App</h1>
          <Search onSearch={handleSearch} />
        </div>      
      <ShowPosts allposts={searchedPosts} />
    </div>
  );
}
export default App;
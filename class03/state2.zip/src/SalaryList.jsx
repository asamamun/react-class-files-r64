/* const SalaryList = ({ salaryArray }) => {
    return (
        <ul>
            {salaryArray.map((item) => (
                <li key={item.id}>
                    {item.name} - {item.salary}
                </li>
            ))}
        </ul>
    );
}; */
const SalaryList = ({ salaryArray },index) => (
        <ul>
            {salaryArray.map((item) => (
                <li key={index}>
                    {item.name} - {item.amount}
                </li>
            ))}
        </ul>
    );
;
export default SalaryList;
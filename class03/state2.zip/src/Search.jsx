const Search = (props) => {
  return (
    <div className="search-container">             
      <input type="text" placeholder="Search..." className="search-input form-control" onChange={props.onSearch} />      
    </div>
  );
};

export default Search;
/* const Search = () => {
  //handleSubmit
  const handleSubmit = (event) => {
    event.preventDefault();
    // Implement search logic here
    console.log("Search submitted");
  };
  return (
    <div className="search-container">
      <form onSubmit={handleSubmit} className="search-form">        
      <input type="text" placeholder="Search..." className="search-input form-control" />
      <button type="submit" className="btn btn-primary">Search</button>
      </form>
    </div>
  );
};

export default Search; */
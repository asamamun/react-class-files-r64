import React from "react";
import Posts from "./Posts";
import Search from "./Search";
import ShowPosts from "./ShowPosts";
const App = ({color}) => {
const [searchTerm, setSearchTerm] = React.useState(localStorage.getItem('search') || '');
React.useEffect(() => {
 localStorage.setItem('search', searchTerm);
 }, [searchTerm]);

//callback handler for search input
const handleSearch = (event) => {
setSearchTerm(event.target.value);
// localStorage.setItem('search', event.target.value);
};
const searchedPosts = Posts.filter(function (post) {
return post.title.toLowerCase().includes(searchTerm.toLowerCase())
});
  return (
    <div className="bg-info" style={{ 
      backgroundColor: color === "dark" ? "#333" : "#fff", 
      color: color === "dark" ? "#fff" : "#000" }}>
        <div className="d-flex justify-content-between">
          <h1>Welcome to My App {searchTerm}</h1>
          <Search onSearch={handleSearch} defaultValue={searchTerm} />
        </div>      
      <ShowPosts allposts={searchedPosts} />
    </div>
  );
}
export default App;
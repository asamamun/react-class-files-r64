const Search = ({onSearch,defaultValue}) => {
  return (
    <div className="search-container">             
      <input type="text" value={defaultValue} placeholder="Search..." className="search-input form-control" onChange={onSearch} />      
    </div>
  );
};
export default Search;

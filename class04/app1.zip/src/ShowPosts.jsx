import SinglePost from "./SinglePost";
const ShowPosts = ({ allposts }) => (
    allposts.map((p) =>
        <div key={p.id}>
            <SinglePost post={p} />
            <hr />
        </div>
    )
)
export default ShowPosts;

const SinglePost = ({ post }) => (
  <div key={post.id}>
    <h2>{post.title} by {post.userId}</h2>
    <p>{post.body}</p>
  </div>
);
export default SinglePost;

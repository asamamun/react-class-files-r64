import React, { useState, useEffect } from 'react';
import UserList from './UserList.jsx';
const App = () => {
    return (
        <div>
        <h1>Hello, World!</h1>
        <p>This is a simple React application.</p>
        <p className="bg-info">The useEffect Hook lets you perform side effects in functional components. Side effects include data fetching, subscriptions, manual DOM manipulation, logging, timers, etc.</p>
        <code>
            <pre>
{`useEffect(() => {
// Your side-effect logic here
return () => {
// Optional cleanup (like removing event listeners or clearing timers)
};
}, [dependencies]);`}
            </pre>
        </code>
        <hr />
        <fieldset>
            <legend>Key Concepts</legend>
            <ul>
                <li>Runs after render – useEffect runs after the DOM is painted.</li>
                <li>Dependencies – The array of dependencies tells React when to re-run the effect.</li>
                <li>[] → Runs once after the initial render (like componentDidMount).</li>
                <li>[someVar] → Runs when someVar changes.</li>
                <li>No array → Runs after every render (like componentDidUpdate).</li>
            </ul>
        </fieldset>
        <hr />
        <h1>Users List</h1>
        <p>Below is a list of users fetched from an API:</p>
        <UserList />
        </div>
    );
}

export default App
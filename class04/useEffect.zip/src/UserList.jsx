import React, { useState, useEffect } from 'react';

function UserList() {
  const [users, setUsers] = useState([]);

  const loadUsers = () => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((response) => response.json())
      .then((data) => setUsers(data))
      .catch((error) => console.error('Error:', error));
  };

  useEffect(() => {
    loadUsers();
    // Cleanup function if needed
    return () => {
      setUsers([]); // Clear users on unmount
    };
  }, []); // Empty array means this runs once on mount

  return (
    <div>
        <button onClick={loadUsers}>Load Users</button>      
      <ul>
        {users.map(user => (
          <li key={user.id}>{user.name}  <span className="close btn btn-danger" onClick={() => setUsers(users.filter(u => u.id !== user.id))}>X</span> </li>
        ))}
      </ul>
    </div>
  );
}
export default UserList;

import list from "./List";
import Item from "./Item";
const App =  ({ color }) => {
  return (
    <div>
      <h1 className="text-center text-primary">Hello, World!</h1>
      <p className="text-secondary">This is a simple React application.</p>
      <p style={{ color: color }}>This text is styled with a dynamic color prop.</p>
      <hr />
        <h2 className="text-success">Item List</h2>
        <ul>
      {
      list.map(item => 
        <Item key={item.objectID} item={item} />
      )
      }
      </ul>
    </div>
  );
}

export default App;
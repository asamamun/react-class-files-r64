import MyInput from "./MyInput";
import React, { useState } from "react";
const App = ({ color }) => {
    // name,email, password state variables
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
  return (
    <div>
      <h1 style={{ color: color }}>Hello, World!</h1>
      <p>This is a simple React application.</p>
      <hr />
        <h2>Form Example</h2>
        <p>Name: {name}</p><p>Email: {email}</p><p>Password: {password}</p>
      <form action="">
        <MyInput label="Name" type="text" value={name} onChange={(e) => setName(e.target.value)} />
        <MyInput label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <MyInput label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button type="submit" className="btn btn-primary mt-3">Submit</button>
      </form>
    </div>
  );
};

export default App;
import { useState, useEffect } from "react";
import React from "react";
function App() {
  const [count, setCount] = useState(0);
  const [calculation, setCalculation] = useState(0);
  const setNewCount = () => {setCount(count + 1);}
  useEffect(() => {
    setCalculation(() => count * 2);
  }, [count]); // <- add the count variable here

  return (
    <React.Fragment>
        <>
      <p>Count: {count}</p>
      <button onClick={() => {setCount(count + 1)}}>+</button>
      <button onClick={setNewCount}>+</button>
      <button onClick={()=> setCount( count + 1)}>+</button>
      <p>Calculation: {calculation}</p>
      </>
    </React.Fragment>
  );

  /* useEffect(() => {
    setTimeout(() => {
      setCount((count) => count + 1);
    }, 1000);
  }, []);

  return <h1>I have rendered {count} times!</h1>; */
}

export default App;
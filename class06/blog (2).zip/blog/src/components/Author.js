import React from 'react';
import Header from './shared/Header';
import BottomNavigation from './shared/BottomNavigation';

const Author = () => {
  const posts = [
    {
      id: 1,
      title: "The Future of AI in Everyday Life",
      date: "July 15, 2023",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBcIyj6ZLeluvLcJgLwub8fJATApZeNwcbbxto7pw2cqE78_-uUdZ-Lfd50xRSFXgeAWaPVwQN8P3BkOQaHCOm_eQ-mlgxYE2vgQVgs379VNjcSIMbIwEYgWxByAxOZrUooErl8trNdQ99S28eBdU7RCsjbvhhATQNWt5s5XiTdKVEw9JgYCy_siYtbeK-qB0uiVt0JrCUCHA_z94WWp2aAuorcBPJzO1GmUu91xTiSZoQx1FkJk39zL7bfaIl9AybsachkLTUhU1RR"
    },
    {
      id: 2,
      title: "Exploring the Metaverse: Opportunities and Challenges",
      date: "June 20, 2023",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuB9XyyDD-cyLG0TW3VC2yZI9SdmNOUFCqQE6tn7Vt4INV_AValkK2RMtBsgBWWTHvg1G9tD69YyqqlRsucrmFjEszpE9ajvwf8pbmU_pr4eFih0QGJnQPTecHz8HNiNy0JBG9WppJNp9dUAWKAtpUnOVMhSWSA_8fYdvi6JGs8Kan_cv6BF3MR7kb8p2F5hXOcryK7wtZc2jNMU4SiWYbSb_-Mka_A8WQQzdJO_0DQ3u_FgXQ6hXq1_JxC7dQhMDuvN_3Srk2A8V6sY"
    },
    {
      id: 3,
      title: "The Rise of Quantum Computing",
      date: "May 5, 2023",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAR2vB3G1F2G1WPPGtMu9lG6yci7TrUL_DfsOL-rO7TOdtZ9BExbIJsQwcqyaxufs5UlK8z1je6yqCROoeaaHAkFv2pT-z8oTGY1IY5KZ0eiF-KiO40Mg0EdmDlluO6yjIwPlTEocRatqHl0yt6zUk1U-ENUfJpAT8Ll2L3XbtRcD_3pIL4TbJUudNgvqaFUBpQmMFRW2tfqMFSpLCuAdaa3ImUbZZ4_2EeYoB38PioZiebX7suH4IrC3l0FzP0M7CPaJCUNuNZQPFs"
    }
  ];

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden">
      <div>
        <Header title="Author Profile" showBack={true} />
        
        {/* Author Profile */}
        <div className="flex p-4 @container">
          <div className="flex w-full flex-col gap-4 items-center">
            <div className="flex gap-4 flex-col items-center">
              <div
                className="bg-center bg-no-repeat aspect-square bg-cover rounded-full min-h-32 w-32"
                style={{
                  backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBdQC7On9QpNjBbLAoy3eMsi_yHNLcno5c2V1ZwHyLmD5BPMZQf_QLWIwDC_qxE6-P1E5Jce_1tx07fi1RU_36tzdrPKIOousmV6DkucYE7xqz1LpjYYFTobzCCNqNAeMSj4KLohyWR6V4ScGKVoesacp7ZHYyFJZP6XVatXqu_MLe7m4rnbiN7IFIplshdtfyHqY7R_BXWVO1PE81DZraq8t8cWhDD3Xngn1o5-mQ-h11kqzu8GUoOkCgDpMga95AETSZAPXW5rmwm")'
                }}
              ></div>
              <div className="flex flex-col items-center justify-center">
                <p className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] text-center">Ethan Carter</p>
                <p className="text-[#60758a] text-base font-normal leading-normal text-center">Tech Enthusiast & Blogger</p>
                <p className="text-[#60758a] text-base font-normal leading-normal text-center">Joined in 2021</p>
              </div>
            </div>
          </div>
        </div>
        
        <p className="text-[#111418] text-base font-normal leading-normal pb-3 pt-1 px-4">
          Ethan Carter is a passionate tech blogger with a focus on emerging technologies and their impact on society. He has been writing about tech trends since 2021.
        </p>

        {/* Published Posts */}
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Published Posts</h2>
        {posts.map(post => (
          <div key={post.id} className="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2">
            <div
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-lg size-14"
              style={{ backgroundImage: `url("${post.image}")` }}
            ></div>
            <div className="flex flex-col justify-center">
              <p className="text-[#111418] text-base font-medium leading-normal line-clamp-1">{post.title}</p>
              <p className="text-[#60758a] text-sm font-normal leading-normal line-clamp-2">{post.date}</p>
            </div>
          </div>
        ))}
      </div>

      <div>
        <BottomNavigation activeTab="profile" />
      </div>
    </div>
  );
};

export default Author;
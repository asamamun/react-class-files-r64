import React from 'react';
import Header from './shared/Header';
import Footer from './shared/Footer';
import SearchBar from './shared/SearchBar';

const Home = () => {
  const posts = [
    {
      id: 1,
      title: "The Future of AI in Business",
      description: "AI is transforming industries, offering new opportunities and challenges.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBwkr_dpRqiscIuywFMZCfZK1yt8p5Ey11FIXkMg3R3JcV5d7SD74ZTnIevvqnStXiLAJtPOAnZ82ZCVteC1Ut4rVb11ZyoV9l_iXv5wRR38mFuFbAMFAItTJqorb-k6LzyNb3-vT_GaqM2QQg-Qf6ogpvfDCBi73R9W3nGIIVJa91zrG7MYQjhEVWg0zYB7_MOQhsO1VdeCxL09ZlFYoVafmoHn4wBYpmAnjpdqX-rveSU1KNQfQHpYisTpFeJHwM_Cd0RB6Z5yXaV"
    },
    {
      id: 2,
      title: "Design Thinking for Startups",
      description: "Apply design thinking principles to build innovative products and services.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCV4hZ4JyZXxmbuXwAuLNuddUdBiujfN-EsDaxz29A9ibxMYi7i8kj8blmOLxTuf4PVp-OWOwQkDpYPPUFwTeEK7tWllvHo-hpcs6VMMnMnCxucjpbhK7FfDHnJNUCrinc8MG---aUmyTjWaL8bPab0W-sD8ddWfGZAQnz3R-Mze_FsKA0VTNgIvqfH6RY8HfF_qbvoIXvHukQfgJGFBTYfvew6J6Kjc2hhFmee-XCL3S4awUYeXgRwYQOQXBktdBmLVXxOuFXj8pR1"
    },
    {
      id: 3,
      title: "Sustainable Tech Trends",
      description: "Explore the latest trends in sustainable technology and their impact.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC_25nxWZga0Ee4iccZMcZIy85ZJ1bPRebCmRHGe599ZZs6IJWx8HM0iyT8oOoW3zVrB3PbPLy5dGWR8PBXABr-bqK1VIepU3Gemt7R-fGrXtyS81uDLXk6mNYiRY7HEEq_D3DlcBAK9MuZb4kwPdwHb4QTW--sFhJdsZY9U0KW-otWN2cvOMakYy6LkTXtT6J7f3QQ0ldhiozC_G6VrlMoPZLdl-XQIM2ufS_Xmy3CsB5tnAI_9P3GhV0SOWlQj8YncTF_g1NPOZgh"
    }
  ];

  const categories = [
    { name: "Technology", icon: "Cpu" },
    { name: "Design", icon: "PencilSimple" },
    { name: "Innovation", icon: "Lightbulb" },
    { name: "Sustainability", icon: "Plant" }
  ];

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden">
      <div>
        <Header title="Blog" showSearch={true} />
        
        {/* Featured Post */}
        <div className="@container">
          <div className="@[480px]:px-4 @[480px]:py-3">
            <div
              className="bg-cover bg-center flex flex-col justify-end overflow-hidden bg-white @[480px]:rounded-lg min-h-[218px]"
              style={{
                backgroundImage: 'linear-gradient(0deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 25%), url("https://lh3.googleusercontent.com/aida-public/AB6AXuBId0jN-L423Wb2fjmQeWER9xrvS6__mGakqiGFH-hFWywci058TcoqGwj03Dia1ogsBlcV1TX62urVopHs_qWlG0-UB6F0VLtgi-xYIv_LT8Cc0PomihRa-3DTlRvyE51DTWjyZnSkas5CKL8M433yMPrC2fZXu5dwgSa0HevOTLyt7PIRKPTR4Pz4QpJqmVzcuiZPBp1e3QpvV3NonXGTMzSSzwtgNo8bjiCLoZ0zThM6eOPtJSX54DkOAYd7VKdJ5W3MXFZKWcay")'
              }}
            >
              <div className="flex p-4">
                <p className="text-white tracking-light text-[28px] font-bold leading-tight">Featured Post</p>
              </div>
            </div>
          </div>
        </div>
        
        <p className="text-[#111418] text-base font-normal leading-normal pb-3 pt-1 px-4">
          Explore the latest insights and trends in technology, design, and innovation. Our featured post highlights a key topic to keep you informed and inspired.
        </p>

        {/* Latest Posts */}
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Latest Posts</h2>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
          {posts.map(post => (
            <div key={post.id} className="flex flex-col gap-3 pb-3">
              <div
                className="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-lg"
                style={{ backgroundImage: `url("${post.image}")` }}
              ></div>
              <div>
                <p className="text-[#111418] text-base font-medium leading-normal">{post.title}</p>
                <p className="text-[#60758a] text-sm font-normal leading-normal">{post.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Categories */}
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Categories</h2>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
          {categories.map(category => (
            <div key={category.name} className="flex flex-1 gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 items-center">
              <div className="text-[#111418] w-6 h-6">
                {/* Icon placeholder */}
                <div className="w-6 h-6 bg-gray-300 rounded"></div>
              </div>
              <h2 className="text-[#111418] text-base font-bold leading-tight">{category.name}</h2>
            </div>
          ))}
        </div>
      </div>

      <div>
        <SearchBar />
        <Footer />
      </div>
    </div>
  );
};

export default Home;
import React from 'react';
import Header from './shared/Header';
import BottomNavigation from './shared/BottomNavigation';

const Single = () => {
  const comments = [
    {
      id: 1,
      author: "Ethan Bennett",
      date: "2 days ago",
      content: "Great article! I've always wanted to visit the Pacific Northwest, and this has inspired me to explore beyond the usual tourist spots.",
      avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuAp24D00-HGONRumVZ2tQ9XQW_EXUNsI2oRVL-iPNyqOarlOq2OXfomvtmwuK-8ADY4po02Py_CsuDbUHjuS3anJtv-hDQx61q0_GIoJ2iG5hsLyTXrfQ4gSh4Yd_13h1UAxq3BN4ZV4mzrPMnLwb7Y5fnIGdhSlCYovcJxmB6QLvZB1BERBHhIWfr0mgobou6HwhUaR3gKuDhrA7dvupX1POJQJN73SEo9jByPAhYRLm9FNJKFlthQUrWiaM-l38dVpxMksCSrizlF"
    },
    {
      id: 2,
      author: "Olivia Hayes",
      date: "1 day ago",
      content: "I live in Oregon and can confirm that the hidden gems are truly worth discovering. Thanks for sharing these recommendations!",
      avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuD2A8uglYORtAF04SaZX8nH68L1UMFX9F43jnFR1BvNqlXnzfnWjdYbp_LfTjqYwPUGUu_3oRDuNnqtWLt6v_pinl04wXFkSg4X9XMv_v_BYPPRGRkMg6tgI_FrOu_vPYqGOYUAqSVFEBcSBlVsCCeO7ipqVHJd0EkQ3KGMbox5yrgHRlY-bwAWrLj8L5DTOL5gheXwxXwCZP0wQRqBG64uToDFej34aKKmMb6nrJOFmLryff9vQHrj1qCBB0VpDxlsxNIVXlARq1qO"
    }
  ];

  const relatedPosts = [
    {
      id: 1,
      title: "A Guide to Hiking in the Rockies",
      description: "Explore the best trails and scenic views in the Rocky Mountains.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAAqXXfGQArfwoGj9xh150kBq3L1fkuTqMMEM2r2rSDyIyLsdDGCGXtHs_kgrHQ1QPZYO9MEeVhTV6gbexCjMiasLmGuFFZ2abmY1hRlWI4ED_HfLYVOIXwW_qfDqeKKdFru2AY0uMtyewBiWn1Wuz4lL7ZNjy7lzVyA2QufZoTI330Fqy19lJboWcfEzJlvwUlpWCEAZZaegKHbfdV_a3lS2yu89AJlyQ6e7cSc_6xTnxfXlvYRBEMoP6iCj8qyqSWszr6nb_oprw8"
    },
    {
      id: 2,
      title: "The Best Beaches in California",
      description: "Discover the most beautiful and secluded beaches along the California coast.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD50USip8uT4TnptsOvQ2Gg56_LgdXWR2iCYReaUYoDlss2yAfgv0fYZnovEG-4EbrOdeI4dIuR59rl_rjNOm68y7ixLV9HmDDS4nVrFUZQ5Hc7jFionFmS1raUmedyPe88sW_2Bzcd43I4qG5FgUIkFyPPdkFvnZQO-nHCIs8ukBzhDjDiRC2AKPUTv4FRW8uZvosTEZuZfcTnB4pRZEdQTMGZtZG73kKV3fkeAJ2MXjI8CMkBFm8wNUn34f7ii9exXHq81JOdPxxD"
    }
  ];

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden">
      <div>
        <Header title="Blog Post" showBack={true} />
        
        {/* Hero Image */}
        <div className="@container">
          <div className="@[480px]:px-4 @[480px]:py-3">
            <div
              className="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-end overflow-hidden bg-white @[480px]:rounded-lg min-h-80"
              style={{
                backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuApqsl-AxzU132UwcWBOu5WdHROp77UGPMeuiFfO0jUa3ZYK70XA52u8s2vlxiUnUH3EFov67oYT90i0wLhKyL_A3apHGQZ54qA2t5BANQRP03IbyWcZ48HMaSlgPEcTtrcP5mSTN4me78buVFM_kjRDgIYdY-pNXWIk0rR_vMhKP9AbDyTZpNatfugRKxSJa2nXvxnCugwPRfo1hL3QJhO3nythrJmqgau0BRlVscDjDLW7L6_UtUyibAKiF9qcSjxV6JoNj6zpQfF")'
              }}
            ></div>
          </div>
        </div>

        {/* Article Title */}
        <h1 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 text-left pb-3 pt-5">
          Exploring the Hidden Gems of the Pacific Northwest
        </h1>

        {/* Author Info */}
        <div className="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2">
          <div
            className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-fit"
            style={{
              backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuD-YaN9f8P62NgkkEcLfSIafGW2KRgzw1ICBrPeP0-_f1AauaPY_gqPJGrB1l1snSR0f21dk4bqm3CEpZPXoTj1Vyqn2pP1qOGkaIT8casEp6ecNEuR4-yNl6EkJOcCV-IVxdCMDj37TjRhhXKSU01hbKe_oxS4eWOrTTFa6DxgvfCu3O0LV43DfSS1Tcm1VXMUu8yJxxSBvINFjFJMEhB00tdVVrnm_NK2tMvM_qvNTkJfgQHFnT8GHLaCcJzjphYdKtXWlmIkASmf")'
            }}
          ></div>
          <div className="flex flex-col justify-center">
            <p className="text-[#111418] text-base font-medium leading-normal line-clamp-1">Sophia Carter</p>
            <p className="text-[#60758a] text-sm font-normal leading-normal line-clamp-2">Travel Enthusiast</p>
          </div>
        </div>

        <p className="text-[#60758a] text-sm font-normal leading-normal pb-3 pt-1 px-4">Published on July 15, 2024</p>

        {/* Article Content */}
        <div className="px-4 space-y-4">
          <p className="text-[#111418] text-base font-normal leading-normal">
            The Pacific Northwest is a region of stunning natural beauty, from the rugged coastline to the towering mountains and lush forests. While popular destinations like Seattle and Portland draw many visitors, there are countless hidden gems waiting to be discovered. In this post, we'll explore some of the lesser-known spots that offer unique experiences and breathtaking scenery.
          </p>
          
          <p className="text-[#111418] text-base font-normal leading-normal">
            One such gem is the Olympic National Park in Washington State. Beyond the famous Hoh Rainforest, the park boasts diverse ecosystems, including glacier-capped peaks, wild beaches, and temperate rainforests. Hiking trails lead to secluded waterfalls, pristine lakes, and panoramic viewpoints, offering a sense of solitude and connection with nature.
          </p>
          
          <p className="text-[#111418] text-base font-normal leading-normal">
            Further south, the Oregon Coast is home to charming towns like Cannon Beach and Astoria, but venture off the beaten path to discover hidden coves, dramatic sea stacks, and tide pools teeming with marine life. The Samuel H. Boardman Scenic Corridor offers stunning coastal vistas, while the Tillamook Rock Lighthouse stands as a testament to the region's maritime history.
          </p>
          
          <p className="text-[#111418] text-base font-normal leading-normal">
            For those seeking adventure, the Cascade Mountains offer endless opportunities for hiking, climbing, and skiing. Mount Rainier National Park is a popular choice, but consider exploring the less crowded North Cascades National Park, known for its rugged peaks, turquoise lakes, and abundant wildlife. The park's trails range from easy day hikes to challenging multi-day treks, catering to all skill levels.
          </p>
          
          <p className="text-[#111418] text-base font-normal leading-normal">
            No exploration of the Pacific Northwest is complete without experiencing its vibrant culinary scene. Beyond the trendy restaurants in major cities, discover local farmers' markets, artisanal food producers, and craft breweries. Sample fresh seafood, locally grown produce, and award-winning wines, immersing yourself in the region's rich flavors.
          </p>
        </div>

        {/* Comments Section */}
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Comments</h2>
        {comments.map(comment => (
          <div key={comment.id} className="flex w-full flex-row items-start justify-start gap-3 p-4">
            <div
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-10 shrink-0"
              style={{ backgroundImage: `url("${comment.avatar}")` }}
            ></div>
            <div className="flex h-full flex-1 flex-col items-start justify-start">
              <div className="flex w-full flex-row items-start justify-start gap-x-3">
                <p className="text-[#111418] text-sm font-bold leading-normal tracking-[0.015em]">{comment.author}</p>
                <p className="text-[#60758a] text-sm font-normal leading-normal">{comment.date}</p>
              </div>
              <p className="text-[#111418] text-sm font-normal leading-normal">{comment.content}</p>
            </div>
          </div>
        ))}

        {/* Related Posts */}
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Related Posts</h2>
        {relatedPosts.map(post => (
          <div key={post.id} className="p-4">
            <div className="flex items-stretch justify-between gap-4 rounded-lg">
              <div className="flex flex-col gap-1 flex-[2_2_0px]">
                <p className="text-[#111418] text-base font-bold leading-tight">{post.title}</p>
                <p className="text-[#60758a] text-sm font-normal leading-normal">{post.description}</p>
              </div>
              <div
                className="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-lg flex-1"
                style={{ backgroundImage: `url("${post.image}")` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <div>
        <BottomNavigation activeTab="home" />
      </div>
    </div>
  );
};

export default Single;
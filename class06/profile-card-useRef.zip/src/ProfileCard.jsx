import React, { useRef } from 'react';

function ProfileCard() {
  const moreInfoRef = useRef(null); // Create a ref for the hidden section

  const handleShowMore = () => {
    //toggle the visibility of the hidden section
    if (moreInfoRef.current.style.display === 'block') {
      moreInfoRef.current.style.display = 'none';
      return;
    }
    moreInfoRef.current.style.display = 'block';
    
    // Scroll to the hidden section when button is clicked
    moreInfoRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div style={styles.card}>
      <img
        src="https://placehold.co/100"
        alt="Profile"
        style={styles.image}
      />
      <h2>Jane Doe</h2>
      <p>Frontend Developer</p>

      <button onClick={handleShowMore} style={styles.button}>
        Show More
      </button>

      <div ref={moreInfoRef} style={styles.hiddenSection}>
        <h4>More Info</h4>
        <p>Email: jane@example.com</p>
        <p>Location: San Francisco</p>
      </div>
    </div>
  );
}

const styles = {
  card: {
    width: '300px',
    padding: '16px',
    border: '1px solid #ddd',
    borderRadius: '12px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    fontFamily: 'sans-serif',
    margin: 'auto',
    textAlign: 'center',
    overflow: 'auto',
    maxHeight: '400px',
  },
  image: {
    borderRadius: '50%',
    width: '100px',
    marginBottom: '8px',
  },
  button: {
    marginTop: '12px',
    padding: '8px 12px',
    border: 'none',
    borderRadius: '6px',
    backgroundColor: '#007bff',
    color: 'white',
    cursor: 'pointer',
  },
  hiddenSection: {
    display: 'none',
    marginTop: '40px',
    paddingTop: '20px',
    borderTop: '1px solid #eee',
  },
};

export default ProfileCard;

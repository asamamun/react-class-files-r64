import Header from "./Header";
import ProfileCard from "./ProfileCard";
const App = ({ color }) => {

  return (
    <div>
      <Header bgcolor={color}> 
        <h1>Welcome to React</h1> 
      </Header>
      <h2>Profile Card Example</h2>
      <ProfileCard/>
    </div>
  );
};

export default App;
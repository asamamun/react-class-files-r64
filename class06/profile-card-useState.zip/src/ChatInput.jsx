import React, { useState, useRef, useEffect } from 'react';

function ChatInput({ onSend, shouldFocus }) {
  const [message, setMessage] = useState('');
  const inputRef = useRef(null); // useRef দিয়ে DOM element ধরবো

  // যখন shouldFocus true হয়, ইনপুটে ফোকাস দিবো
  useEffect(() => {
    if (shouldFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [shouldFocus]);

  const handleSend = () => {
    if (message.trim() === '') return;

    onSend(message);
    setMessage(''); // useState দিয়ে UI আপডেট হবে
  };

  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <input
        ref={inputRef} // DOM element access করার জন্য useRef
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message"
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}

export default ChatInput;

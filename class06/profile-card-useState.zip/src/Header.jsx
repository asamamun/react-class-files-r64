const Header = ({bgcolor,children}) => {
  return (
    <section style={{ backgroundColor: bgcolor }}>
      {children}
    </section>
  );
}
/* const Header = (props) => {
  return (
    <section style={{ backgroundColor: props.bgcolor }}>
      {props.children}
    </section>
  );
} */
export default Header;
import React, { useState } from 'react';

function ProfileCard() {
  const [showMore, setShowMore] = useState(false); // React state to control visibility

  const handleShowMore = () => {
    setShowMore((showMore) => !showMore); // toggle state
  };
  return (
    <div style={styles.card}>
      <img
        src="https://placehold.co/100"
        alt="Profile"
        style={styles.image}
      />
      <h2>Jane Doe</h2>
      <p>Frontend Developer</p>

      <button onClick={handleShowMore} style={styles.button}>
        {showMore ? 'Hide' : 'Show More'}
      </button>

      {showMore && (
        <div style={styles.hiddenSection}>
          <h4>More Info</h4>
          <p>Email: jane@example.com</p>
          <p>Location: San Francisco</p>
        </div>
      )}
    </div>
  );
}


const styles = {
  card: {
    width: '300px',
    padding: '16px',
    border: '1px solid #ddd',
    borderRadius: '12px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    fontFamily: 'sans-serif',
    margin: 'auto',
    textAlign: 'center',
    overflow: 'auto',
    maxHeight: '400px',
  },
  image: {
    borderRadius: '50%',
    width: '100px',
    marginBottom: '8px',
  },
  button: {
    marginTop: '12px',
    padding: '8px 12px',
    border: 'none',
    borderRadius: '6px',
    backgroundColor: '#007bff',
    color: 'white',
    cursor: 'pointer',
  },
  hiddenSection: {
    marginTop: '40px',
    paddingTop: '20px',
    borderTop: '1px solid #eee',
  },
};

export default ProfileCard;

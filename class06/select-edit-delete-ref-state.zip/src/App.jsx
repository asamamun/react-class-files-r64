import React from 'react';
import { Modal } from 'bootstrap';
const App = ({ color }) => {

  //use a state variable to store the products
  const [products, setProducts] = React.useState([]);
  //form  variables in ref
  const idRef = React.useRef();
  const titleRef = React.useRef();
  const stockRef = React.useRef();
  const priceRef = React.useRef();
  const modalRef = React.useRef(null);

  //get products from 'https://dummyjson.com/products'
  const fetchProducts = async () => {
    try {
      const response = await fetch('https://dummyjson.com/products');
      const data = await response.json();
      console.log(data);
      // Update the state with the fetched products
      setProducts(data.products);
    } catch (error) {
      console.error(error);
    }
  };
  //delete a product from the products array
  const deleteProduct = (id) => {
    const updatedProducts = products.filter(product => product.id !== id);
    setProducts(updatedProducts);
    console.log(updatedProducts);
  };
  // Open modal programmatically
  const openEditModal = (product) => {
    titleRef.current.value = product.title;
    stockRef.current.value = product.stock;
    priceRef.current.value = product.price;
    idRef.current.value = product.id;

    const modalElement = document.getElementById('editModal');
    if (!modalRef.current) {
      modalRef.current = new Modal(modalElement, {
        backdrop: true,
        keyboard: true
      });
    }
    modalRef.current.show();
  };

  //save the product after editing
  const SaveProduct = () => {
    console.log("Save product");
    const updatedProducts = products.map(product => {
      if (product.id == idRef.current.value) {
        return {
          ...product,
          title: titleRef.current.value,
          stock: stockRef.current.value,
          price: priceRef.current.value
        };
      }
      return product;
    });
    setProducts(updatedProducts);

    // Close modal cleanly
    if (modalRef.current) {
      modalRef.current.hide();
    }
  };
  return (
    <div>
      <h1>Hello from {color}</h1>
      <button onClick={fetchProducts}>Fetch products</button>
      <div className='row'>
        {products.map((product) => (
          <div className='col-3' key={product.id}>
            <img src={product.thumbnail} alt="" className='w-20' />
            {product.title} - ${product.price}
            <hr />
            {/* edit and delete option */}
            <button className='btn btn-primary' onClick={() => openEditModal(product)}>Edit</button>
            <button className='btn btn-danger' onClick={() => deleteProduct(product.id)}>Delete</button>
          </div>
        ))}
      </div>
      {/* modal for edit only title, stock and price */}
      <div className='modal fade' id='editModal' tabIndex='-1' aria-labelledby='editModalLabel' aria-hidden='true'>
        <div className='modal-dialog'>
          <div className='modal-content'>
            <div className='modal-header'>
              <h5 className='modal-title' id='editModalLabel'>Edit Product</h5>
              <button type='button' className='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
            </div>
            <div className='modal-body'>
              {/* Form for editing product */}
              <form>
                <input type="hidden" ref={idRef} />
                <div className='mb-3'>
                  <label htmlFor='title' className='form-label'>Title</label>
                  <input ref={titleRef} type='text' className='form-control' />
                </div>
                <div className='mb-3'>
                  <label htmlFor='stock' className='form-label'>Stock</label>
                  <input ref={stockRef} type='number' className='form-control' />
                </div>
                <div className='mb-3'>
                  <label htmlFor='price' className='form-label'>Price</label>
                  <input ref={priceRef} type='number' className='form-control' />
                </div>
              </form>
            </div>
            <div className='modal-footer'>
              <button type='button' className='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
              <button type='button' className='btn btn-primary' onClick={SaveProduct}>Save changes</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
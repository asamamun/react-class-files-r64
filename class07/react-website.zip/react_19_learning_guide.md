# React 19 Learning Guide

## ⚖️ Getting Started
- What is React?
- Setting up a React project (Vite, CRA, or Next.js)
- Folder structure and project anatomy
- JSX syntax and expressions
- Functional components vs. Class components (focus on functional)

## ⚙️ Core Concepts

### Props (passing data)

**Props** (short for "properties") allow you to pass data from one component to another, typically from a parent to a child.

#### Defining a Component with Props

```jsx
function Greeting(props) {
  return <h1>Hello, {props.name}!</h1>;
}
```

#### Using the Component

```jsx
function App() {
  return <Greeting name="Alice" />;
}
```

#### Destructuring Props

```jsx
function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}
```

#### Notes:

- Props are **read-only**.
- You can pass any JavaScript value: strings, numbers, objects, functions, etc.

#### Passing Multiple Props

```jsx
function UserCard({ name, age }) {
  return <p>{name} is {age} years old.</p>;
}

function App() {
  return <UserCard name="Bob" age={30} />;
}
```

#### Default Props (Optional)

```jsx
function Greeting({ name = "Guest" }) {
  return <h1>Hello, {name}!</h1>;
}
```

### State with `useState`

`useState` is a React Hook used to create state variables in functional components.

#### Example

```jsx
import { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
    </div>
  );
}
```

### Event Handling

React uses camelCase for event names and passes event objects as parameters.

```jsx
function ClickHandler() {
  function handleClick(e) {
    alert('Button clicked');
  }

  return <button onClick={handleClick}>Click Me</button>;
}
```

### Conditional Rendering

```jsx
function UserGreeting({ isLoggedIn }) {
  return (
    <div>
      {isLoggedIn ? <h1>Welcome back!</h1> : <h1>Please sign in.</h1>}
    </div>
  );
}
```

### Lists and Keys

```jsx
function NumberList({ numbers }) {
  return (
    <ul>
      {numbers.map((num) => (
        <li key={num}>{num}</li>
      ))}
    </ul>
  );
}
```

- Always provide a unique `key` prop when rendering lists.

### Fragments

Fragments let you group elements without adding extra nodes to the DOM.

```jsx
<>
  <h1>Title</h1>
  <p>Description</p>
</>
```

## ♻️ React Hooks

### `useState`

Used for managing local component state (covered above).

### `useEffect`

Used to handle side effects (data fetching, subscriptions, etc.).

```jsx
import { useEffect, useState } from 'react';

function UserProfile({ userId }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch(`/api/user/${userId}`)
      .then((res) => res.json())
      .then((data) => setUser(data));
  }, [userId]);

  return user ? <div>{user.name}</div> : <p>Loading...</p>;
}
```

### `useRef`

Used for accessing DOM elements and persisting values across renders.

```jsx
import { useRef } from 'react';

function TextInput() {
  const inputRef = useRef();

  const focusInput = () => {
    inputRef.current.focus();
  };

  return (
    <>
      <input ref={inputRef} />
      <button onClick={focusInput}>Focus Input</button>
    </>
  );
}
```

### `useContext`

Used to consume values from React Context.

```jsx
const ThemeContext = React.createContext('light');

function ThemeButton() {
  const theme = useContext(ThemeContext);
  return <button>{`Theme is ${theme}`}</button>;
}
```

### `useReducer`

Alternative to `useState` for complex state logic.

```jsx
function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return { count: state.count + 1 };
    default:
      return state;
  }
}

function Counter() {
  const [state, dispatch] = useReducer(reducer, { count: 0 });

  return (
    <>
      Count: {state.count}
      <button onClick={() => dispatch({ type: 'increment' })}>+</button>
    </>
  );
}
```

### `useCallback` and `useMemo`

Used for memoization to avoid unnecessary re-renders or recomputations.

```jsx
const memoizedCallback = useCallback(() => {
  doSomething();
}, [dependencies]);

const memoizedValue = useMemo(() => computeExpensiveValue(a, b), [a, b]);
```

### 🌟 `use` Hook (React 19)

The `use` hook enables awaiting promises directly inside components (server or client).

```jsx
function UserComponent() {
  const user = use(fetchUser()); // auto-suspends until resolved
  return <div>Hello, {user.name}</div>;
}
```

## 🧹 Component Architecture
- Container vs. presentational components
- Lifting state up
- Composing components
- Controlled vs. uncontrolled components
- Error boundaries (`<ErrorBoundary>`)

## 🎨 Styling in React
- CSS Modules
- Styled-components
- Tailwind CSS
- Inline styles
- CSS-in-JS (Emotion, etc.)

## 📆 Forms and Input Handling
- Controlled inputs
- Form validation
- Libraries: Formik, React Hook Form

## 🌐 Routing
- React Router v6+
  - `BrowserRouter`, `Routes`, `Route`
  - Navigation with `Link` and `useNavigate`
  - Dynamic routes, nested routes

## 🔌 Data Fetching & APIs
- Fetching with `fetch` or Axios
- `useEffect` for side effects
- Async/await patterns
- SWR or React Query
- 🌟 Server Actions (in Next.js 14+)

## ⚡ State Management
- Context API
- Zustand
- Redux Toolkit
- Recoil, Jotai (optional)

## 💻 React 19 & Server Components
- What are Server Components?
- Using `use` to await async data
- React Compiler and automatic memoization
- Differences from Client Components
- Loading UI patterns (`<Suspense>`)

## 📉 Advanced Patterns
- Render props
- Higher-Order Components (HOCs)
- Custom hooks
- Code splitting and lazy loading
- Portals (e.g., for modals)

## 🔐 Authentication & Authorization
- JWT, sessions, OAuth (Google, GitHub, etc.)
- Protected routes
- Role-based rendering

## ⚙️ Testing in React
- Unit testing with Jest
- Component testing with React Testing Library
- End-to-end testing with Cypress or Playwright

## 📦 Performance Optimization
- Memoization (`React.memo`, `useMemo`)
- Virtualization (e.g., `react-window`)
- Avoiding unnecessary re-renders
- Lazy loading and code splitting
- React Profiler

## 🌍 TypeScript with React
- Typing props and state
- Typed hooks
- Interfaces vs. types

## 🚀 React + Next.js (Optional but Highly Recommended)
- File-based routing
- Server and Client Components
- API routes
- Image optimization
- App directory (`app/` folder)
- Layouts, loading UI, error UI

## 📤 Deployment
- Vercel, Netlify, Render
- Dockerizing a React app
- Environment variables
- Build optimization

## 💪 What's New in React 19
- `use` hook for async logic
- Actions & Server Functions
- New `formState` for native form handling
- Server Components enhancements
- React Compiler (automatic memoization)

## 🗂️ Bonus
- Component libraries: shadcn/ui, Material UI, Ant Design
- Accessibility (a11y)
- Internationalization (i18n)


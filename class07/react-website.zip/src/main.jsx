import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '@fortawesome/fontawesome-free/css/all.min.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    
      <App />
    
  </StrictMode>,
)
/* console.log("React version:");
let x = {name: "React", version: "18.2.0"};
const {version} = x;//object destructuring
console.log(x);
console.log(version); */
/* class Person {
constructor(firstName, lastName) {
this.firstName = firstName;
this.lastName = lastName;
}
getName() {
return this.firstName + ' ' + this.lastName;
}
}
const person = new Person('John', 'Doe');
console.log(person.getName()); // John Doe
const person2 = new Person('Mr', 'Smith');
console.log(person2.getName()); // Mr Smith */

/* const user = {
  firstName: 'Robin',
  pet: {
    name: 'Trixi',
  },
};
// without object destructuring
const firstName = user.firstName;
const name = user.pet.name;

// with nested object destructuring
const {
  firstName1,
  pet: { name1 },
} = user;
console.log(firstName, name); // Robin Trixi
console.log(firstName1, name1); // Robin Trixi */
const Blogs = () => {
  return (
    <div>
      <h1>Blogs Page</h1>
      <p>Welcome to the blogs page!</p>
    </div>
  );
}

export default Blogs;
<?php
//allow cors
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
// Database connection
$conn = new mysqli("localhost", "root", "", "web1ecomm");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
// Set the timezone to Asia/Kolkata
date_default_timezone_set('Asia/Dhaka');
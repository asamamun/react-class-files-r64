-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2025 at 12:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web1ecomm`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role` set('1','2','3') NOT NULL DEFAULT '1' COMMENT '2=admin,3=user, moderator=1\r\n',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$3m4tiCKzsH4bwbWNLwI26uQv5UghRSoDZZENjNrzuzujluBlD.1gW', '2', '2022-12-21 07:45:31'),
(4, 'Iqbal Hossain', 'abcd@gmail.com', '$2y$10$cAZfy3BWyQACvz3aGL7gTeiy7IwhIkWNM14Edj8turit.O8SbupMW', '2', '2022-12-21 07:47:14'),
(5, 'mamun', 'mamun@gmail.com', '$2y$10$LXXoFhw/hYMjBWtToAZCSu.vidUKCuUjNu1chVWhLPTIri9iNOAa2', '2', '2022-12-21 07:47:25'),
(6, 'Ananta Kumar Das', 'anantakumar@gmail.com', '$2y$10$6WS5p9weW5tSpMY1OGbUiO9gHPQqwcXKWlC9LrnJaX2bQ.zqg9Q9.', '2', '2022-12-21 07:48:07'),
(7, 'owishi', 'ohichowdhury25@gmail.com', '$2y$10$/.ZhazhaeIz/wR5nlGptn.tWCw8K0c9MMV6dyP8h66KHe3q9z7ofq', '2', '2022-12-21 07:48:16'),
(8, 'Fatema', 'brazil@gmail.com', '$2y$10$1IhuQl/hLGcNmvxYU/ZNPO7sv4MhrGMI2kO97tA6yX.1ZnWE.Zvy6', '2', '2022-12-21 07:48:19'),
(12, 'ananta', 'abc@gmail.com', '$2y$10$ds9z.wZvpm9Ll9dNR5OmoegLrEDRdmkX0uf2/KnTyZJaYTTq/zt2u', '2', '2022-12-21 08:02:20'),
(19, 'Ridoy', 'ridoymojumder922@gmail.com', '$2y$10$lwgXBdRuF0pjDjcKvEjKLOQUsgo7KadoJGGsuVzWl6XYSorjgFnIu', '2', '2022-12-21 08:13:05'),
(21, 'Najmul', 'abcde@gmail.com', '$2y$10$ZWQ/U.oF0.h88K.M5UgPf.WzRPiOGZzYNGwPvRm0cMWBTAzNeuWkq', '2', '2022-12-21 08:13:47'),
(22, 'nurmohammad', 'nurmohammad@gmail.com', '$2y$10$hZYiGAjdf2quzCNhbwO.QuM2jH8avSq9pyu.1vnOR4qTkYjJUuRpW', '2', '2022-12-21 08:14:03'),
(23, 'sharif', 'sharif1234567th@gmail.com', '$2y$10$ONxIPD/4hvbK0RyRtWv5T.vazydG1auSUemOGdSVIHKjRlrTwyFDW', '2', '2022-12-21 08:15:20'),
(24, 'Akhi', 'akhi@gmail.com', '$2y$10$5Iatqny.DMWDJhnbrcXA6.TYlMLlU4xcfRggTp3Vb2ifJAiwiHnSC', '2', '2022-12-21 08:15:52'),
(25, 'Najmul', 'najmul@gmail.com', '$2y$10$rq.hYr8iJAKmV20ZPxtDOOgfftgb5tZaW4DuAnS2I1NQ9ZiWlxruC', '2', '2022-12-26 07:32:45'),
(26, 'Fatema', 'fatema@gmail.com', '$2y$10$cigzrjVqVyxIQvqj9JFxkeJypp1lMgP.oGZTSrJURCxTtG/GS07jC', '2', '2022-12-26 08:07:28'),
(31, 'owishi', 'owishichowdhury@gmail.com', '$2y$10$orxPkywyBQbmmdkC2DT56uPMAvZ31mEl8ScKME.88wfjqiYW5zRO2', '2', '2022-12-26 09:00:48'),
(32, 'khusnur Akther', 'adibaakhi@gmail.com', '$2y$10$Tr/Lx7ld7iMePaAwEgFM6eoKZv1rDe0j.50zod.mQUgNgQumRaK6.', '2', '2022-12-26 09:01:13'),
(35, 'Ananta', 'ananta@gmail.com', '$2y$10$KbMOU8IZQABOwHmYlKy19.PA8fWCwvr34Ng9vt08qUeyE/tUHG/VO', '2', '2022-12-27 06:34:25'),
(36, 'Rabbi ', 'rabbi@gmail.com', '$2y$10$2muWrv9b5Pt5V4GrigE/iuOAAuGg02SFQOQbwJUs3Yx/15mXZwRdi', '2', '2022-12-27 06:36:39'),
(42, 'owishi', 'chowdhuryowishi@gmail.com', '$2y$10$rwM2On7t/xvHTb.UFl0nbuxFIojC9N0XKNdn8mSmU7bcYz0/p.EnG', '2', '2022-12-27 06:41:17'),
(43, 'Rabbi Hossain', 'shantooo123@gmail.com', '$2y$10$0WHeoK1koFgf.OnCt49lJ.xWZ9S9y1QrY.eOw88YFOfscSe7.ccg.', '2', '2022-12-27 06:41:47'),
(45, 'Shahin Hossain', 'shshahin61@gmail.com', '$2y$10$caEEJdlC9VgTf2B5yEmmluB8Q.2CUXlPj6k/SZ2F3piM8f.utaDFG', '2', '2022-12-27 06:44:15'),
(55, 'shanto', 'shantooo383@gmail.com', '$2y$10$ZPvuyCHrQwI1IVs6IBkycekn9ab2OtHOhzujcYhqKccwNna7j./Va', '2', '2022-12-27 06:49:51'),
(84, 'khusnur akther', 'akhi@mail.com', '$2y$10$HTeJyznRBb6/vsKcgW.H8OkhB6R58ysX3umqCKDnag3blo1n74j5O', '1', '2022-12-30 05:44:19'),
(85, 'MAJEDA AKTER', 'majeda123@gmail.com', '$2y$10$fatVJICgQD6KHY4UTYuda.zAF54JvXAz8WBi3O6wEWbImjZMoGLR2', '1', '2022-12-30 05:44:40'),
(86, 'Israt Jahan ', 'promi1199if@gmail.com', '$2y$10$9ecC.JmATQo9K/UZ2gdnReW0IBDzoKkTISWF63de2t/h9t0VpeS4.', '1', '2022-12-30 05:49:45'),
(88, 'akhii', 'akhii@gmail.com', '$2y$10$TYQ557dTPFtPpNIjAyX.X.YQrlsOhm56Ep4E0DBLNKlXmlJMKZvi.', '1', '2023-11-13 09:30:34'),
(89, 'newadmin', 'newadmin@gmail.com', '$2y$10$zmxEoh/ny3qbSKC86Bh18.BywAcPgboQOMUV3xtF4rEe5H2zXIIqy', '2', '2023-11-13 09:38:15'),
(90, 'test', 'test77@gmail.com', '$2y$10$IfPi.eiqNN4Vj0t5qpYm8Ozfr044HCVnH3tnV59cM38DS.jNbYAga', '2', '2023-11-21 08:05:35'),
(91, 'round57', 'round57@gmail.com', '$2y$10$V5ivEdoc8Ff6IOOJu8CKHOyH9bSBNSd7ivIFqcylPp43G6YDz0.UK', '2', '2024-04-24 03:39:45'),
(92, 'ttt', 'ttt@gmail.com', '$2y$10$iwgG8Nwfu9L2cJ/8aXOr7uXXuWe6brerXP7tALL1pKQooNcjtbVze', '2', '2024-04-27 05:54:15'),
(93, 'gen', 'gen@gmail.com', '$2y$10$QrYF6d7e1D7qgQ66KBvUTubRx7Nae1S7/xOrz9AaCTU868cbtLe4K', '3', '2024-05-15 05:37:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

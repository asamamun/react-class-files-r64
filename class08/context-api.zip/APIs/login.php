<?php
session_start();
header("Content-Type: application/json");
require_once "DB/connection.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data["email"] ?? "");
$password = trim($data["password"] ?? "");

if (!$email || !$password) {
    echo json_encode(["error" => "Email and password required"]);
    exit;
}

$stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 1) {
    $stmt->bind_result($id, $email, $hash);
    $stmt->fetch();
    if (password_verify($password, $hash)) {
        $_SESSION["user"] = ["id" => $id, "email" => $email];
        echo json_encode(["user" => ["id" => $id, "email" => $email]]);
    } else {
        echo json_encode(["error" => "Invalid credentials"]);
    }
} else {
    echo json_encode(["error" => "Invalid credentials"]);
}
$stmt->close();
$conn->close();
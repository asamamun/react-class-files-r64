# React 19 Learning Guide

## ⚖️ Getting Started

- What is React?
- Setting up a React project (Vite, CRA, or Next.js)
- Folder structure and project anatomy
- JSX syntax and expressions
- Functional components vs. Class components (focus on functional)

## ⚙️ Core Concepts

### Props (passing data)

**Props** (short for "properties") allow you to pass data from one component to another, typically from a parent to a child.

#### Defining a Component with Props

```jsx
function Greeting(props) {
  return <h1>Hello, {props.name}!</h1>;
}
```

#### Using the Component

```jsx
function App() {
  return <Greeting name="Alice" />;
}
```

#### Destructuring Props

```jsx
function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}
```

#### Notes:

- Props are **read-only**.
- You can pass any JavaScript value: strings, numbers, objects, functions, etc.

#### Passing Multiple Props

```jsx
function UserCard({ name, age }) {
  return <p>{name} is {age} years old.</p>;
}

function App() {
  return <UserCard name="Bob" age={30} />;
}
```

#### Default Props (Optional)

```jsx
function Greeting({ name = "Guest" }) {
  return <h1>Hello, {name}!</h1>;
}
```

### State with `useState`

`useState` is a React Hook used to create state variables in functional components.

#### Example

```jsx
import { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
    </div>
  );
}
```

### Event Handling

React uses camelCase for event names and passes event objects as parameters.

```jsx
function ClickHandler() {
  function handleClick(e) {
    alert('Button clicked');
  }

  return <button onClick={handleClick}>Click Me</button>;
}
```

### Conditional Rendering

```jsx
function UserGreeting({ isLoggedIn }) {
  return (
    <div>
      {isLoggedIn ? <h1>Welcome back!</h1> : <h1>Please sign in.</h1>}
    </div>
  );
}
```

### Lists and Keys

```jsx
function NumberList({ numbers }) {
  return (
    <ul>
      {numbers.map((num) => (
        <li key={num}>{num}</li>
      ))}
    </ul>
  );
}
```

- Always provide a unique `key` prop when rendering lists.

### Fragments

Fragments let you group elements without adding extra nodes to the DOM.

```jsx
<>
  <h1>Title</h1>
  <p>Description</p>
</>
```

## ♻️ React Hooks

### `useState`

Used for managing local component state (covered above).

### `useEffect`

Used to handle side effects (data fetching, subscriptions, etc.).

```jsx
import { useEffect, useState } from 'react';

function UserProfile({ userId }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch(`/api/user/${userId}`)
      .then((res) => res.json())
      .then((data) => setUser(data));
  }, [userId]);

  return user ? <div>{user.name}</div> : <p>Loading...</p>;
}
```

### `useRef`

Used for accessing DOM elements and persisting values across renders.

```jsx
import { useRef } from 'react';

function TextInput() {
  const inputRef = useRef();

  const focusInput = () => {
    inputRef.current.focus();
  };

  return (
    <>
      <input ref={inputRef} />
      <button onClick={focusInput}>Focus Input</button>
    </>
  );
}
```

### `useContext`

Used to consume values from React Context.

```jsx
const ThemeContext = React.createContext('light');

function ThemeButton() {
  const theme = useContext(ThemeContext);
  return <button>{`Theme is ${theme}`}</button>;
}
```

### `useReducer`

Alternative to `useState` for complex state logic.

```jsx
function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return { count: state.count + 1 };
    default:
      return state;
  }
}

function Counter() {
  const [state, dispatch] = useReducer(reducer, { count: 0 });

  return (
    <>
      Count: {state.count}
      <button onClick={() => dispatch({ type: 'increment' })}>+</button>
    </>
  );
}
```

### `useCallback` and `useMemo`

Used for memoization to avoid unnecessary re-renders or recomputations.

```jsx
const memoizedCallback = useCallback(() => {
  doSomething();
}, [dependencies]);

const memoizedValue = useMemo(() => computeExpensiveValue(a, b), [a, b]);
```

### 🌟 `use` Hook (React 19)

The `use` hook enables awaiting promises directly inside components (server or client).

```jsx
function UserComponent() {
  const user = use(fetchUser()); // auto-suspends until resolved
  return <div>Hello, {user.name}</div>;
}
```

- Requires usage in frameworks that support React 19 features (e.g., Next.js App Router).

## 🧠 Component Architecture

... (existing content retained) ...

## 📝 Forms and Input Handling

### Controlled Components

Controlled components tie form input values to React state.

```jsx
function FormExample() {
  const [inputValue, setInputValue] = useState('');

  const handleChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Submitted: ${inputValue}`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={inputValue} onChange={handleChange} />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### Handling Multiple Inputs

```jsx
function MultiInputForm() {
  const [formData, setFormData] = useState({ name: '', email: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <form>
      <input name="name" value={formData.name} onChange={handleChange} />
      <input name="email" value={formData.email} onChange={handleChange} />
    </form>
  );
}
```

### Form Validation (Basic)

```jsx
function ValidatedForm() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.includes('@')) {
      setError('Invalid email');
    } else {
      setError(null);
      alert('Valid email submitted');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={email} onChange={(e) => setEmail(e.target.value)} />
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit">Submit</button>
    </form>
  );
}
```

## 🌍 Routing with React Router (v6+)

### Basic Setup

```bash
npm install react-router-dom
```

### Basic Usage

```jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Home';
import About from './About';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </BrowserRouter>
  );
}
```

### Route Parameters

```jsx
<Route path="/user/:id" element={<User />} />
```

Access the `id` param:

```jsx
import { useParams } from 'react-router-dom';

function User() {
  const { id } = useParams();
  return <div>User ID: {id}</div>;
}
```

### Navigation

```jsx
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/about">About</Link>
    </nav>
  );
}
```

You can also programmatically navigate using `useNavigate()`.


import React from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import Login from "./component/Login";
import Register from "./component/Register";
import Logout from "./component/Logout";

function Home() {
  const { auth } = useAuth();
  return (
    <div>
      {auth ? (
        <>
          <h1>Welcome, {auth.email}</h1>
          <Logout />
        </>
      ) : (
        <>
          <Login />
          <Register />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Home />
    </AuthProvider>
  );
}
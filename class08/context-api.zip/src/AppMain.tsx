import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from "./context/AuthContext";
import Login from "./component/Login";
import Register from "./component/Register";
import Logout from "./component/Logout";

// Mock AOS functionality since we can't import external libraries
const AOS = {
  init: (options?: any) => { },
  refresh: () => { }
};

// Header Component
const Header = ({ toggleSidebar, currentPage, setCurrentPage }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary fixed-top shadow-sm">
      <div className="container-fluid">
        <button
          className="btn btn-outline-light me-3"
          onClick={toggleSidebar}
          type="button"
        >
          <i className="fas fa-bars"></i>
        </button>
        <div className="navbar-brand fw-bold" onClick={() => setCurrentPage('home')} style={{ cursor: 'pointer' }}>
          <i className="fas fa-rocket me-2"></i>
          MyApp
        </div>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <div
                className={`nav-link ${currentPage === 'home' ? 'active' : ''}`}
                onClick={() => setCurrentPage('home')}
                style={{ cursor: 'pointer' }}
              >
                Home
              </div>
            </li>
            <li className="nav-item">
              <div
                className={`nav-link ${currentPage === 'about' ? 'active' : ''}`}
                onClick={() => setCurrentPage('about')}
                style={{ cursor: 'pointer' }}
              >
                About
              </div>
            </li>
            <li className="nav-item">
              <div
                className={`nav-link ${currentPage === 'products' ? 'active' : ''}`}
                onClick={() => setCurrentPage('products')}
                style={{ cursor: 'pointer' }}
              >
                Products
              </div>
            </li>
            <li className="nav-item">
              <div
                className={`nav-link ${currentPage === 'contact' ? 'active' : ''}`}
                onClick={() => setCurrentPage('contact')}
                style={{ cursor: 'pointer' }}
              >
                Contact
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

// Sidebar Component
const Sidebar = ({ isOpen, toggleSidebar, currentPage, setCurrentPage, handleNavClick }) => {
  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50 d-lg-none"
          style={{ zIndex: 1040 }}
          onClick={toggleSidebar}
        ></div>
      )}

      {/* Sidebar */}
      <div
        className={`position-fixed top-0 start-0 h-100 bg-light shadow-lg transition-all ${isOpen ? 'translate-x-0' : 'translate-x-n100'
          } d-lg-block`}
        style={{
          width: '280px',
          zIndex: 1050,
          marginTop: '76px',
          transform: isOpen ? 'translateX(0)' : 'translateX(-100%)',
          transition: 'transform 0.3s ease-in-out'
        }}
      >
        <div className="p-4">
          <h5 className="text-primary mb-4">
            <i className="fas fa-list me-2"></i>
            Navigation
          </h5>
          <ul className="list-unstyled">
            <li className="mb-2">
              <div
                className={`text-decoration-none d-flex align-items-center p-2 rounded ${currentPage === 'home' ? 'bg-primary text-white' : 'text-dark hover-bg-light'
                  }`}
                onClick={() => handleNavClick('home')}
                style={{ cursor: 'pointer' }}
              >
                <i className="fas fa-home me-3"></i>
                Home
              </div>
            </li>
            <li className="mb-2">
              <div
                className={`text-decoration-none d-flex align-items-center p-2 rounded ${currentPage === 'about' ? 'bg-primary text-white' : 'text-dark hover-bg-light'
                  }`}
                onClick={() => handleNavClick('about')}
                style={{ cursor: 'pointer' }}
              >
                <i className="fas fa-info-circle me-3"></i>
                About
              </div>
            </li>
            <li className="mb-2">
              <div
                className={`text-decoration-none d-flex align-items-center p-2 rounded ${currentPage === 'products' ? 'bg-primary text-white' : 'text-dark hover-bg-light'
                  }`}
                onClick={() => handleNavClick('products')}
                style={{ cursor: 'pointer' }}
              >
                <i className="fas fa-box me-3"></i>
                Products
              </div>
            </li>
            <li className="mb-2">
              <div
                className={`text-decoration-none d-flex align-items-center p-2 rounded ${currentPage === 'contact' ? 'bg-primary text-white' : 'text-dark hover-bg-light'
                  }`}
                onClick={() => handleNavClick('contact')}
                style={{ cursor: 'pointer' }}
              >
                <i className="fas fa-envelope me-3"></i>
                Contact
              </div>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

// Footer Component
const Footer = ({ setCurrentPage }) => {
  return (
    <footer className="bg-dark text-light py-5 mt-5">
      <div className="container">
        <div className="row" data-aos="fade-up">
          <div className="col-lg-4 mb-4">
            <h5 className="text-primary mb-3">
              <i className="fas fa-rocket me-2"></i>
              MyApp
            </h5>
            <p className="text-muted">
              Building amazing digital experiences with modern technologies and innovative solutions.
            </p>
            <div className="d-flex gap-3">
              <div className="text-light" style={{ cursor: 'pointer' }}>
                <i className="fab fa-facebook-f"></i>
              </div>
              <div className="text-light" style={{ cursor: 'pointer' }}>
                <i className="fab fa-twitter"></i>
              </div>
              <div className="text-light" style={{ cursor: 'pointer' }}>
                <i className="fab fa-linkedin-in"></i>
              </div>
              <div className="text-light" style={{ cursor: 'pointer' }}>
                <i className="fab fa-instagram"></i>
              </div>
            </div>
          </div>
          <div className="col-lg-2 col-md-6 mb-4">
            <h6 className="text-uppercase mb-3">Company</h6>
            <ul className="list-unstyled">
              <li><div onClick={() => setCurrentPage('about')} className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>About Us</div></li>
              <li><div onClick={() => setCurrentPage('products')} className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Products</div></li>
              <li><div onClick={() => setCurrentPage('contact')} className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Contact</div></li>
              <li><div className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Careers</div></li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-6 mb-4">
            <h6 className="text-uppercase mb-3">Support</h6>
            <ul className="list-unstyled">
              <li><div className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Help Center</div></li>
              <li><div className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Documentation</div></li>
              <li><div className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Privacy Policy</div></li>
              <li><div className="text-muted text-decoration-none" style={{ cursor: 'pointer' }}>Terms of Service</div></li>
            </ul>
          </div>
          <div className="col-lg-3 mb-4">
            <h6 className="text-uppercase mb-3">Newsletter</h6>
            <p className="text-muted small mb-3">Subscribe to get updates on our latest features.</p>
            <div className="input-group">
              <input type="email" className="form-control" placeholder="Your email" />
              <button className="btn btn-primary" type="button">
                <i className="fas fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div>
        <hr className="my-4" />
        <div className="row align-items-center">
          <div className="col-md-6">
            <p className="text-muted small mb-0">
              © 2025 MyApp. All rights reserved.
            </p>
          </div>
          <div className="col-md-6 text-md-end">
            <p className="text-muted small mb-0">
              Made with <i className="fas fa-heart text-danger"></i> by MyApp Team
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

// Page Components
const Home = ({ setCurrentPage }) => {
  useEffect(() => {
    AOS.refresh();
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary text-white py-5 mb-5">
        <div className="container">
          <div className="row align-items-center min-vh-50">
            <div className="col-lg-6" data-aos="fade-right">
              <h1 className="display-4 fw-bold mb-4">
                Welcome to MyApp
              </h1>
              <p className="lead mb-4">
                Discover amazing features and build incredible experiences with our modern platform.
              </p>
              <div className="d-flex gap-3">
                <button onClick={() => setCurrentPage('products')} className="btn btn-light btn-lg">
                  <i className="fas fa-rocket me-2"></i>
                  Get Started
                </button>
                <button onClick={() => setCurrentPage('about')} className="btn btn-outline-light btn-lg">
                  Learn More
                </button>
              </div>
            </div>
            <div className="col-lg-6" data-aos="fade-left">
              <div className="text-center">
                <i className="fas fa-laptop-code" style={{ fontSize: '10rem', opacity: 0.8 }}></i>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-5">
        <div className="container">
          <div className="row text-center mb-5">
            <div className="col-lg-8 mx-auto" data-aos="fade-up">
              <h2 className="display-5 fw-bold text-primary mb-3">Why Choose MyApp?</h2>
              <p className="lead text-muted">
                We provide cutting-edge solutions that help you achieve more with less effort.
              </p>
            </div>
          </div>

          <div className="row g-4">
            <div className="col-lg-4" data-aos="fade-up" data-aos-delay="100">
              <div className="card h-100 border-0 shadow-sm">
                <div className="card-body text-center p-4">
                  <div className="bg-primary bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style={{ width: '80px', height: '80px' }}>
                    <i className="fas fa-bolt text-primary fa-2x"></i>
                  </div>
                  <h5 className="card-title fw-bold">Lightning Fast</h5>
                  <p className="card-text text-muted">
                    Experience blazing fast performance with our optimized infrastructure.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-4" data-aos="fade-up" data-aos-delay="200">
              <div className="card h-100 border-0 shadow-sm">
                <div className="card-body text-center p-4">
                  <div className="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style={{ width: '80px', height: '80px' }}>
                    <i className="fas fa-shield-alt text-success fa-2x"></i>
                  </div>
                  <h5 className="card-title fw-bold">Secure & Reliable</h5>
                  <p className="card-text text-muted">
                    Your data is protected with enterprise-grade security measures.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-4" data-aos="fade-up" data-aos-delay="300">
              <div className="card h-100 border-0 shadow-sm">
                <div className="card-body text-center p-4">
                  <div className="bg-info bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style={{ width: '80px', height: '80px' }}>
                    <i className="fas fa-users text-info fa-2x"></i>
                  </div>
                  <h5 className="card-title fw-bold">24/7 Support</h5>
                  <p className="card-text text-muted">
                    Get help whenever you need it with our dedicated support team.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const About = () => {
  useEffect(() => {
    AOS.refresh();
  }, []);

  return (
    <div className="container py-5">
      <div className="row">
        <div className="col-lg-8 mx-auto">
          <div className="text-center mb-5" data-aos="fade-up">
            <h1 className="display-4 fw-bold text-primary mb-4">About MyApp</h1>
            <p className="lead text-muted">
              We're passionate about creating innovative solutions that make a difference.
            </p>
          </div>

          <div className="row g-4 mb-5">
            <div className="col-md-6" data-aos="fade-right">
              <div className="card h-100 border-0 bg-light">
                <div className="card-body p-4">
                  <h5 className="card-title text-primary mb-3">
                    <i className="fas fa-eye me-2"></i>
                    Our Vision
                  </h5>
                  <p className="card-text">
                    To revolutionize the way people interact with technology by creating intuitive,
                    powerful, and accessible solutions for everyone.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6" data-aos="fade-left">
              <div className="card h-100 border-0 bg-light">
                <div className="card-body p-4">
                  <h5 className="card-title text-primary mb-3">
                    <i className="fas fa-bullseye me-2"></i>
                    Our Mission
                  </h5>
                  <p className="card-text">
                    We strive to deliver exceptional products and services that exceed expectations
                    while fostering innovation and growth in our community.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center" data-aos="fade-up">
            <h3 className="fw-bold text-primary mb-4">Our Story</h3>
            <p className="text-muted mb-4">
              Founded in 2020, MyApp started as a small team of developers with a big dream.
              Today, we've grown into a trusted platform serving thousands of users worldwide.
              Our journey has been driven by innovation, dedication, and a commitment to excellence.
            </p>
            <div className="row text-center g-4">
              <div className="col-md-3">
                <h4 className="text-primary fw-bold">1000+</h4>
                <p className="text-muted">Happy Customers</p>
              </div>
              <div className="col-md-3">
                <h4 className="text-primary fw-bold">50+</h4>
                <p className="text-muted">Team Members</p>
              </div>
              <div className="col-md-3">
                <h4 className="text-primary fw-bold">25+</h4>
                <p className="text-muted">Countries Served</p>
              </div>
              <div className="col-md-3">
                <h4 className="text-primary fw-bold">99.9%</h4>
                <p className="text-muted">Uptime</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Products = () => {
  useEffect(() => {
    AOS.refresh();
  }, []);

  const products = [
    {
      id: 1,
      name: 'Pro Plan',
      price: '$29',
      period: '/month',
      features: ['Advanced Analytics', 'Priority Support', 'Custom Integrations', 'API Access'],
      icon: 'fas fa-star',
      color: 'primary',
      popular: true
    },
    {
      id: 2,
      name: 'Basic Plan',
      price: '$9',
      period: '/month',
      features: ['Basic Analytics', 'Email Support', 'Standard Features', '5GB Storage'],
      icon: 'fas fa-rocket',
      color: 'success'
    },
    {
      id: 3,
      name: 'Enterprise',
      price: '$99',
      period: '/month',
      features: ['Custom Solutions', '24/7 Phone Support', 'Unlimited Everything', 'Dedicated Manager'],
      icon: 'fas fa-crown',
      color: 'warning'
    }
  ];

  return (
    <div className="container py-5">
      <div className="text-center mb-5" data-aos="fade-up">
        <h1 className="display-4 fw-bold text-primary mb-4">Our Products</h1>
        <p className="lead text-muted">
          Choose the perfect plan that fits your needs and budget.
        </p>
      </div>

      <div className="row g-4">
        {products.map((product, index) => (
          <div key={product.id} className="col-lg-4" data-aos="fade-up" data-aos-delay={index * 100}>
            <div className={`card h-100 border-0 shadow-sm position-relative ${product.popular ? 'border-primary' : ''}`}>
              {product.popular && (
                <div className="position-absolute top-0 start-50 translate-middle">
                  <span className="badge bg-primary px-3 py-2">Most Popular</span>
                </div>
              )}
              <div className="card-body text-center p-4">
                <div className={`bg-${product.color} bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3`} style={{ width: '80px', height: '80px' }}>
                  <i className={`${product.icon} text-${product.color} fa-2x`}></i>
                </div>
                <h4 className="card-title fw-bold mb-3">{product.name}</h4>
                <div className="mb-4">
                  <span className="display-4 fw-bold text-primary">{product.price}</span>
                  <span className="text-muted">{product.period}</span>
                </div>
                <ul className="list-unstyled mb-4">
                  {product.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="mb-2">
                      <i className="fas fa-check text-success me-2"></i>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className={`btn btn-${product.color} btn-lg w-100`}>
                  Choose Plan
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  useEffect(() => {
    AOS.refresh();
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Handle form submission here
    alert('Message sent successfully!');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5" data-aos="fade-up">
        <h1 className="display-4 fw-bold text-primary mb-4">Contact Us</h1>
        <p className="lead text-muted">
          Get in touch with us. We'd love to hear from you!
        </p>
      </div>

      <div className="row g-5">
        <div className="col-lg-8" data-aos="fade-right">
          <div className="card border-0 shadow-sm">
            <div className="card-body p-4">
              <h4 className="card-title mb-4">Send us a message</h4>
              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="name" className="form-label">Full Name</label>
                    <input
                      type="text"
                      className="form-control"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="col-12">
                    <label htmlFor="subject" className="form-label">Subject</label>
                    <input
                      type="text"
                      className="form-control"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="col-12">
                    <label htmlFor="message" className="form-label">Message</label>
                    <textarea
                      className="form-control"
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>
                  <div className="col-12">
                    <button type="submit" className="btn btn-primary btn-lg">
                      <i className="fas fa-paper-plane me-2"></i>
                      Send Message
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-4" data-aos="fade-left">
          <div className="row g-4">
            <div className="col-12">
              <div className="card border-0 bg-primary text-white">
                <div className="card-body p-4 text-center">
                  <i className="fas fa-map-marker-alt fa-2x mb-3"></i>
                  <h5 className="card-title">Visit Us</h5>
                  <p className="card-text">
                    123 Main Street<br />
                    New York, NY 10001<br />
                    United States
                  </p>
                </div>
              </div>
            </div>

            <div className="col-12">
              <div className="card border-0 bg-success text-white">
                <div className="card-body p-4 text-center">
                  <i className="fas fa-phone fa-2x mb-3"></i>
                  <h5 className="card-title">Call Us</h5>
                  <p className="card-text">
                    +1 (555) 123-4567<br />
                    Mon - Fri, 9AM - 5PM EST
                  </p>
                </div>
              </div>
            </div>

            <div className="col-12">
              <div className="card border-0 bg-info text-white">
                <div className="card-body p-4 text-center">
                  <i className="fas fa-envelope fa-2x mb-3"></i>
                  <h5 className="card-title">Email Us</h5>
                  <p className="card-text">
                    info@myapp.com<br />
                    support@myapp.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentPage, setCurrentPage] = useState('home');

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleNavClick = (page: string) => {
    setCurrentPage(page);
    // Only close sidebar on mobile (screen width < 992px)
    if (window.innerWidth < 992) {
      setSidebarOpen(false);
    }
  };

  useEffect(() => {
    // Initialize AOS
    AOS.init({
      duration: 1000,
      once: true,
      offset: 100
    });
  }, []);

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home setCurrentPage={setCurrentPage} />;
      case 'about':
        return <About />;
      case 'products':
        return <Products />;
      case 'contact':
        return <Contact />;
      default:
        return <Home setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="App">

      <style>{`
        body {
          padding-top: 76px;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .min-vh-50 {
          min-height: 50vh;
        }
        
        .hover-bg-light:hover {
          background-color: #f8f9fa !important;
        }
        
        .transition-all {
          transition: all 0.3s ease;
        }
        
        .translate-x-0 {
          transform: translateX(0);
        }
        
        .translate-x-n100 {
          transform: translateX(-100%);
        }
        
        @media (min-width: 992px) {
          body {
            padding-left: 280px;
          }
        }
        
        .card {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
        }
        
        .navbar-brand {
          font-size: 1.5rem;
        }
        
        .bg-opacity-10 {
          background-color: rgba(var(--bs-primary-rgb), 0.1) !important;
        }
      `}</style>

      <Header toggleSidebar={toggleSidebar} currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} currentPage={currentPage} setCurrentPage={setCurrentPage} handleNavClick={handleNavClick} />

      <main className="flex-grow-1">
        {renderCurrentPage()}
      </main>

      <Footer setCurrentPage={setCurrentPage} />
    </div>
  );
};

export default App;
import React, { createContext, useState, useContext } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(() => {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
  });

  const login = async (email, password) => {
    // Replace with your API endpoint
    const res = await fetch("http://localhost/ROUND64/react/my-app/APIs/login.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (data.user) {
      setAuth(data.user);
      localStorage.setItem("user", JSON.stringify(data.user));
      return true;
    }
    return false;
  };

  const register = async (email, password) => {
    // Replace with your API endpoint
    const res = await fetch("http://localhost/ROUND64/react/my-app/APIs/register.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (data.user) {
      setAuth(data.user);
      localStorage.setItem("user", JSON.stringify(data.user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setAuth(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ auth, login, register, logout, setAuth }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
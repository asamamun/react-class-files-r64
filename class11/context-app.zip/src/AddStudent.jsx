import { useState } from 'react';
import { useStudentsDispatch } from './StudentsContext.jsx';

let nextId = 4;

export default function AddStudent() {
  const [name, setName] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const dispatch = useStudentsDispatch();

  return (
    <div>
      <h2>Add New Student</h2>
      <input
        placeholder="Name"
        value={name}
        onChange={e => setName(e.target.value)}
      />
      <input
        placeholder="Blood Group (e.g., A+)"
        value={bloodGroup}
        onChange={e => setBloodGroup(e.target.value)}
      />
      <button
        onClick={() => {
          if (name && bloodGroup) {
            dispatch({
              type: 'added',
              id: nextId++,
              name,
              bloodGroup
            });
            setName('');
            setBloodGroup('');
          }
        }}
        disabled={!name || !bloodGroup}
      >
        Add Student
      </button>
    </div>
  );
}
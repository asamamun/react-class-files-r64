import { useStudents } from './StudentsContext.jsx';

const AnotherNestedComponent = () => {
    const students = useStudents();
    return (
        <div>
            <h2>Another Nested Component</h2>
            <ul>
                {students.map(student => (
                    <li key={student.id}>{student.name} - {student.bloodGroup}</li>
                ))}
            </ul>
        </div>
    )
}
export default AnotherNestedComponent;
import { useStudents, useStudentsDispatch } from './StudentsContext.jsx';
import AnotherNestedComponent from './AnotherNestedComponent.jsx';

export default function NestedComponent() {
  const students = useStudents();
  const dispatch = useStudentsDispatch();

  return (
    <div>
      <h2>Nested Component (Showing Students)</h2>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            {student.name} - {student.bloodGroup}
            <button
              onClick={() => {
                dispatch({
                  type: 'deleted',
                  id: student.id
                });
              }}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
      <AnotherNestedComponent />
    </div>
  );
}
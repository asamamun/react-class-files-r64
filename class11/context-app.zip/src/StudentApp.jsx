import { StudentsProvider } from './StudentsContext.jsx';
import StudentList from './StudentList.jsx';
import AddStudent from './AddStudent.jsx';
import NestedComponent from './NestedComponent.jsx';

export default function StudentApp() {
  return (
    <StudentsProvider>
      <h1>Student Management</h1>
      <AddStudent />
      <StudentList />
      <NestedComponent />
    </StudentsProvider>
  );
}
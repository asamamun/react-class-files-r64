import { useStudents, useStudentsDispatch } from './StudentsContext.jsx';
import { useContext } from 'react';

export default function StudentList() {
  // const students = useContext(StudentsContext);
  const students = useStudents();
  const dispatch = useStudentsDispatch();

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            Name: {student.name} , Blood Group: ({student.bloodGroup})
            <button
              onClick={() => {
                dispatch({
                  type: 'deleted',
                  id: student.id
                });
              }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
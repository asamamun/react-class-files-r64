import { createContext, useContext, useReducer } from 'react';

export const StudentsContext = createContext(null);
export const StudentsDispatchContext = createContext(null);

export function StudentsProvider({ children }) {
  const [students, dispatch] = useReducer(studentsReducer, initialStudents);

  return (
    <StudentsContext.Provider value={students}>
      <StudentsDispatchContext.Provider value={dispatch}>
        {children}
      </StudentsDispatchContext.Provider>
    </StudentsContext.Provider>
  );
}

export function useStudents() {
  return useContext(StudentsContext);
}

export function useStudentsDispatch() {
  return useContext(StudentsDispatchContext);
}

function studentsReducer(students, action) {
  switch (action.type) {
    case 'added': {
      return [...students, {
        id: action.id,
        name: action.name,
        bloodGroup: action.bloodGroup
      }];
    }
    case 'deleted': {
      return students.filter(s => s.id !== action.id);
    }
    default: {
      throw Error('Unknown action: ' + action.type);
    }
  }
}

const initialStudents = [
  { id: 1, name: 'Alice Smith', bloodGroup: 'A+' },
  { id: 2, name: 'Bob Johnson', bloodGroup: 'B-' },
  { id: 3, name: 'Charlie Brown', bloodGroup: 'O+' }
];
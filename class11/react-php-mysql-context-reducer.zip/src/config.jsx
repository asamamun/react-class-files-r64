const API_URL = 'http://localhost/ROUND64/react/react-php-mysql-based-ecommerce/API/';
export default API_URL;
import { useState, useCallback } from 'react'
import './App.css'
import Todos from './Todos'

function App() {
  const [count, setCount] = useState(0)
  const [todos, setTodos] = useState([])

  const increment = () => {
    setCount((c) => c + 1)
  }

  // Problem version - function gets recreated on every render
  const addTodo = () => {
    console.log("addTodo called");
    setTodos((t) => [...t, "New Todo"])
  }

  // Solution version - function is memoized with useCallback
  const addTodoWithCallback = useCallback(() => {
    console.log("addTodoWithCallback called");
    setTodos((t) => [...t, "New Todo"])
  }, []) // Empty dependency array since we don't depend on any values

  return (
    <div className="App">
      <h1>React useCallback Hook Example</h1>
      
      <div style={{ marginBottom: '20px' }}>
        <h2>Problem Version (without useCallback)</h2>
        <p>Click the count button and watch the console - Todos component re-renders unnecessarily!</p>
        <Todos todos={todos} addTodo={addTodo} info="addTodo called" />
        <hr />
        <div>
          Count: {count}
          <button onClick={increment}>+</button>
        </div>
      </div>

      <div style={{ marginTop: '40px' }}>
        <h2>Solution Version (with useCallback)</h2>
        <p>Click the count button and watch the console - Todos component only re-renders when todos change!</p>
        <Todos todos={todos} addTodo={addTodoWithCallback} info="addTodoWithCallback called" />
        <hr />
        <div>
          Count: {count}
          <button onClick={increment}>+</button>
        </div>
      </div>

      <div style={{ marginTop: '40px', padding: '20px', backgroundColor: '#f0f0f0', borderRadius: '8px' }}>
        <h3>How to test:</h3>
        <ol>
          <li>Open browser console to see render logs</li>
          <li>Click the count increment button (+)</li>
          <li>Notice that in the "Problem Version", the Todos component re-renders even when todos don't change</li>
          <li>In the "Solution Version", the Todos component only re-renders when todos actually change</li>
          <li>Add some todos to see the difference in behavior</li>
        </ol>
      </div>
    </div>
  )
}

export default App

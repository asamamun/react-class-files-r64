import { memo } from "react"

const Todos = ({ todos, addTodo, info }) => {
  console.log("Todos component rendered: " + info)
  return (
    <>
      <h3>My Todos: {info}</h3>
      {todos.map((todo, index) => {
        return <p key={index}>{todo}</p>
      })}
      <button onClick={addTodo}>Add Todo</button>
    </>
  )
}

export default memo(Todos) 
# React useMemo Example

This project demonstrates the use of `useMemo` in React to optimize performance by memoizing expensive calculations.

## What is useMemo?

`useMemo` is a React Hook that memoizes the result of a calculation. It only recalculates the value when one of its dependencies changes, preventing expensive operations from running on every render.

## Why Use useMemo?

1. **Performance Optimization**: Prevents expensive calculations from running on every render
2. **Dependency Control**: Only recalculates when specific dependencies change
3. **Memory Efficiency**: Avoids unnecessary object/array recreation

## The Example

This app demonstrates the difference between:
- **With useMemo**: Calculation only runs when the input number changes
- **Without useMemo**: Calculation runs on every render, even when the input hasn't changed

## How to Run

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm start
   ```

3. Open your browser to `http://localhost:3000`

## How to Test

1. Open your browser's developer console (F12)
2. Click the "Increment Counter" button several times
3. Notice in the console:
   - The "Without useMemo" calculation runs every time you click
   - The "With useMemo" calculation only runs when you change the factorial input

## Key Concepts Demonstrated

### 1. Expensive Calculation
```javascript
const calculateFactorial = (n) => {
  console.log(`Calculating factorial for ${n}...`);
  let result = 1;
  for (let i = 2; i <= n; i++) {
    result *= i;
    // Simulate expensive computation
    const start = Date.now();
    while (Date.now() - start < 1) {}
  }
  return result;
};
```

### 2. With useMemo (Optimized)
```javascript
const factorial = useMemo(() => {
  return calculateFactorial(number);
}, [number]); // Only recalculate when 'number' changes
```

### 3. Without useMemo (Unoptimized)
```javascript
const factorial = calculateFactorial(number); // Runs on every render
```

## When to Use useMemo

✅ **Use useMemo for:**
- Expensive calculations
- Object/array creation that depends on props/state
- API data processing
- Complex filtering/sorting operations

❌ **Don't use useMemo for:**
- Simple calculations
- When the overhead isn't worth it
- When dependencies change frequently

## Performance Impact

In this example, you can see the performance difference by:
1. Opening the browser console
2. Clicking the counter button repeatedly
3. Observing that the non-memoized calculation runs every time
4. The memoized calculation only runs when the input changes

This demonstrates how `useMemo` can significantly improve performance for expensive operations. 
import React, { useState, useMemo } from 'react';

// Example: useMemo with object creation and filtering
const UserList = ({ users, searchTerm }) => {
  // Without useMemo - creates new filtered array on every render
  const filteredUsersWithoutMemo = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // With useMemo - only filters when users or searchTerm changes
  const filteredUsersWithMemo = useMemo(() => {
    console.log('Filtering users...'); // This will only log when dependencies change
    return users.filter(user => 
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [users, searchTerm]);

  // Without useMemo - creates new object on every render
  const statsWithoutMemo = {
    total: users.length,
    filtered: filteredUsersWithoutMemo.length,
    averageAge: users.reduce((sum, user) => sum + user.age, 0) / users.length
  };

  // With useMemo - only creates object when dependencies change
  const statsWithMemo = useMemo(() => {
    console.log('Calculating stats...'); // This will only log when dependencies change
    return {
      total: users.length,
      filtered: filteredUsersWithMemo.length,
      averageAge: users.reduce((sum, user) => sum + user.age, 0) / users.length
    };
  }, [users, filteredUsersWithMemo]);

  return (
    <div style={{ margin: '20px', padding: '20px', border: '1px solid #ccc' }}>
      <h3>User List Example</h3>
      <p>Search Term: {searchTerm}</p>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div>
          <h4>Without useMemo</h4>
          <p>Filtered Users: {filteredUsersWithoutMemo.length}</p>
          <p>Stats: {JSON.stringify(statsWithoutMemo)}</p>
        </div>
        <div>
          <h4>With useMemo</h4>
          <p>Filtered Users: {filteredUsersWithMemo.length}</p>
          <p>Stats: {JSON.stringify(statsWithMemo)}</p>
        </div>
      </div>
    </div>
  );
};

// Example: useMemo with expensive sorting
const SortedList = ({ items, sortBy }) => {
  // Without useMemo - sorts on every render
  const sortedItemsWithoutMemo = [...items].sort((a, b) => {
    console.log('Sorting without memo...'); // This runs on every render
    return a[sortBy].localeCompare(b[sortBy]);
  });

  // With useMemo - only sorts when items or sortBy changes
  const sortedItemsWithMemo = useMemo(() => {
    console.log('Sorting with memo...'); // This only runs when dependencies change
    return [...items].sort((a, b) => a[sortBy].localeCompare(b[sortBy]));
  }, [items, sortBy]);

  return (
    <div style={{ margin: '20px', padding: '20px', border: '1px solid #ccc' }}>
      <h3>Sorted List Example</h3>
      <p>Sorting by: {sortBy}</p>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div>
          <h4>Without useMemo</h4>
          <ul>
            {sortedItemsWithoutMemo.map((item, index) => (
              <li key={index}>{item.name} - {item.category}</li>
            ))}
          </ul>
        </div>
        <div>
          <h4>With useMemo</h4>
          <ul>
            {sortedItemsWithMemo.map((item, index) => (
              <li key={index}>{item.name} - {item.category}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export { UserList, SortedList }; 
import React, { useState, useMemo } from 'react';
import './App.css';
import SimpleExample from './SimpleExample';

// Expensive calculation function
const calculateFactorial = (n) => {
  console.log(`Calculating factorial for ${n}...`);
  let result = 1;
  for (let i = 2; i <= n; i++) {
    result *= i;
    // Simulate delay
    const start = Date.now();
    while (Date.now() - start < 1) {}
  }
  return result;
};

// Random value that changes on every render
const getRandomValue = () => {
  return Math.random().toFixed(4);
};

// Component with useMemo
const MemoizedCalculation = ({ number }) => {
  const factorial = useMemo(() => {
    return calculateFactorial(number);
  }, [number]);

  // This random value will change on every render
  const randomValue = getRandomValue();
  
  // This memoized random value will stay the same until dependencies change
  const memoizedRandomValue = useMemo(() => {
    return getRandomValue();
  }, [number]);

  return (
    <div className="card">
      <h3>With useMemo (Optimized)</h3>
      <p>Input: {number}</p>
      <div className="result">Factorial: {factorial}</div>
      <div className="result">Random Value (changes every render): {randomValue}</div>
      <div className="result">Memoized Random (changes only when input changes): {memoizedRandomValue}</div>
      <div className="performance">
        ✅ Only recalculates when input changes!
      </div>
    </div>
  );
};

// Component without useMemo
const NonMemoizedCalculation = ({ number }) => {
  const factorial = calculateFactorial(number);
  
  // This random value will change on every render
  const randomValue = getRandomValue();

  return (
    <div className="card">
      <h3>Without useMemo (Unoptimized)</h3>
      <p>Input: {number}</p>
      <div className="result">Factorial: {factorial}</div>
      <div className="result">Random Value: {randomValue}</div>
      <div className="performance">
        ⚠️ Recalculates on every render!
      </div>
    </div>
  );
};

function App() {
  const [number, setNumber] = useState(5);
  const [counter, setCounter] = useState(0);

  return (
    <div className="container">
      <h1>React useMemo Example</h1>
      
      <div className="card">
        <h2>What is useMemo?</h2>
        <p>
          <strong>useMemo</strong> memoizes expensive calculations and only 
          recalculates when dependencies change.
        </p>
      </div>

      <div className="card">
        <h2>Controls</h2>
        <div>
          <label>Factorial Input: </label>
          <input
            type="number"
            value={number}
            onChange={(e) => setNumber(parseInt(e.target.value) || 0)}
            className="input"
            min="0"
            max="10"
          />
        </div>
        <div>
          <button 
            onClick={() => setCounter(counter + 1)}
            className="button"
          >
            Increment Counter: {counter}
          </button>
          <p>This triggers re-renders but doesn't affect factorial calculation.</p>
        </div>
      </div>

      <div className="comparison">
        <MemoizedCalculation number={number} />
        <NonMemoizedCalculation number={number} />
      </div>

      <SimpleExample />

      <div className="card">
        <h2>Key Points:</h2>
        <ul>
          <li>Prevents expensive calculations on every render</li>
          <li>Only recalculates when dependencies change</li>
          <li>Check console logs to see the difference!</li>
          <li><strong>Watch the Random Values:</strong> The memoized random value stays the same until you change the input!</li>
        </ul>
      </div>
    </div>
  );
}

export default App; 
import React, { useState, useMemo } from 'react';

// Simple example to demonstrate useMemo with Math.random()
const SimpleExample = () => {
  const [count, setCount] = useState(0);
  const [name, setName] = useState('John');

  // Without useMemo - this will change on every render
  const randomWithoutMemo = Math.random().toFixed(4);
  
  // With useMemo - this will only change when 'name' changes
  const randomWithMemo = useMemo(() => {
    console.log('Calculating memoized random...');
    return Math.random().toFixed(4);
  }, [name]);

  // Expensive calculation without memo
  const expensiveWithoutMemo = (() => {
    console.log('Running expensive calculation without memo...');
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += Math.random();
    }
    return result.toFixed(2);
  })();

  // Expensive calculation with memo
  const expensiveWithMemo = useMemo(() => {
    console.log('Running expensive calculation with memo...');
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += Math.random();
    }
    return result.toFixed(2);
  }, [name]);

  return (
    <div style={{ padding: '20px', border: '2px solid #007bff', borderRadius: '8px', margin: '20px 0' }}>
      <h2>Simple useMemo Example with Math.random()</h2>
      
      <div style={{ marginBottom: '20px' }}>
        <button onClick={() => setCount(count + 1)} style={{ marginRight: '10px' }}>
          Increment Count: {count}
        </button>
        <input 
          value={name} 
          onChange={(e) => setName(e.target.value)}
          placeholder="Change name to trigger memo"
          style={{ padding: '5px', marginRight: '10px' }}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div style={{ border: '1px solid #dc3545', padding: '15px', borderRadius: '5px' }}>
          <h3>Without useMemo</h3>
          <p><strong>Random Value:</strong> {randomWithoutMemo}</p>
          <p><strong>Expensive Result:</strong> {expensiveWithoutMemo}</p>
          <p style={{ color: '#dc3545', fontSize: '12px' }}>
            ⚠️ These values change on EVERY render!
          </p>
        </div>
        
        <div style={{ border: '1px solid #28a745', padding: '15px', borderRadius: '5px' }}>
          <h3>With useMemo</h3>
          <p><strong>Random Value:</strong> {randomWithMemo}</p>
          <p><strong>Expensive Result:</strong> {expensiveWithMemo}</p>
          <p style={{ color: '#28a745', fontSize: '12px' }}>
            ✅ These values only change when 'name' changes!
          </p>
        </div>
      </div>

      <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
        <h4>How to Test:</h4>
        <ol>
          <li>Click "Increment Count" button several times</li>
          <li>Notice the "Without useMemo" values change every time</li>
          <li>Notice the "With useMemo" values stay the same</li>
          <li>Change the name input to see memoized values update</li>
          <li>Check console logs to see when calculations run</li>
        </ol>
      </div>
    </div>
  );
};

export default SimpleExample; 
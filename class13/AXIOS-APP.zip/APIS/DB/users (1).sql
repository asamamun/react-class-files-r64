-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2025 at 10:18 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web2ecomm`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role` set('1','2','3') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(2, 'admin', 'admin@gmail.com', '$2y$10$ITPqwFI8Ofx4lyZiLiWdMOA6EuI/nXNl2qlUl8qItRR1DbjkKZlha', '2', '2022-12-21 05:50:15'),
(3, 'Travis Scott', 'travis@gmail.com', '$2y$10$S6YeD9n/s71HpMjL68nkC.nZDsVrY4juAMz0s2FSV5UNo.iRn3XJ6', '2', '2022-12-21 05:51:32'),
(4, 'prantodeb', 'prantodeb@gmail.com', '$2y$10$SRVMSaqJAGkZAgr64zB6qu1abTCc.dUIDjbWUc/bJpdEZ9VDKVE06', '2', '2022-12-21 05:51:33'),
(5, 'weirdrafi', 'mazharulrafi@gmail.com', '$2y$10$sjUdfuzXaXmk2TIbHkOXneXgmCrsZKjEeEq5NR6RNc7.YFFSFpZqO', '2', '2022-12-21 05:52:14'),
(6, 'Shuvo', 'wafirashraful0186@gmail.com', '$2y$10$6eIVsMk93n.BHXEfB7qifucK.b5ZrjLSDVpMIg20UQtCAP/LipfMq', '2', '2022-12-21 05:52:16'),
(7, 'md.mosaraf', 'mosharof111@gmail.com', '$2y$10$R2PhFyKyXKbKuDERF/zET.NbJ9LMy499uv6HAmqkGz4jhoiRWaSJ.', '2', '2022-12-21 05:52:46'),
(8, 'rahima', 'yeamin123@gmail.com', '$2y$10$lJE.LtR7kPiEVmsTJBoN0ubDr5th3elXCBEX7GIOtahmOPujgdcUW', '2', '2022-12-21 05:53:03'),
(10, 'nishat subha', 'nishatshubah@gmail.com', '$2y$10$SziD.OmavpG2YI7aHdcM5.Vnl7bZ8GCV2/4UsUjrxBmHo40rnnzQy', '2', '2022-12-21 05:54:12'),
(12, 'RAKIB', 'rakib@gmail.com', '$2y$10$GBjYDAX3.quj8TUFz4XeJ.WCUsRbAmRgbrhH94UqdPRlNCX6WJoB.', '2', '2022-12-21 05:56:04'),
(13, 'mamun', 'mamun@gmail.com', '$2y$10$Ye/Fg9wjBMlMlrAgDii7reFIR8Mv17GCXdJbCF3xg2v7LO54p.5CK', '2', '2022-12-21 06:16:28'),
(14, 'weirdrafi', 'rafi@gmail.com', '$2y$10$O6beZa/WaCHQg84bSP1U4uEVKwJg74Key0t0eLKOBlTiNtWpryD..', '2', '2022-12-26 06:57:02'),
(15, 'messi', 'messi123@gmail.com', '$2y$10$TI1sYv9ADY7hvEZ7/ATrbOu8kSbhmQ0XkL8QjpsZ8pwter8EtNnFm', '2', '2022-12-26 06:57:08'),
(18, 'nishat', 'nishat@gmail.com', '$2y$10$xB3f0RqX43mjAq1KgL5lUuskftfjDpL7MqBf9EeOKILVzrCxQl8UG', '1', '2022-12-26 06:59:13'),
(19, 'Akhi Ali', 'akhi@gmail.com', '$2y$10$.I2EFX1Kbecp8oJrrnCAC.DHB1J.Z4UZT0Yr6eej5JNVleDIBrpcS', '1', '2022-12-26 07:02:14'),
(20, 'Mosa: Lima Akter', 'limaislam4334@gmail.com', '$2y$10$r9jxz3Rz7TmIzOSAODQVw.F7wbOBR1YYvmpsvAbKULxAp9lfQLb2i', '1', '2022-12-26 07:02:52'),
(21, 'test', 'test@gmail.com', '$2y$10$vuebGOJRHf4VxKkfIBQ.geSQJ.SAFlsa3kl0E.Gwaj8lf1IO2SqPy', '2', '2022-12-26 07:05:17'),
(22, 'ignes', 'ignesis@gmail.com', '$2y$10$t2ZwoJ7lOLGVv6a8dH5O0eIPuPh4FNMULf/vE0tKKbOC2P8lVPSry', '2', '2022-12-29 05:32:33'),
(23, 'shubo', 'shubo@gmail.com', '$2y$10$OyY5oOfSXhzolalFiHhkpuTfEoQdF37CV6fgoE3DVV24/LvzIRolu', '1', '2022-12-29 05:51:22'),
(24, 'abcd', 'abcd@gmail.com', '$2y$10$OMqzsRwk4picY3ymz5/J9O9qJJqMyDNwUUODDpIsfnOGmjQ5GVJ0.', '2', '2022-12-29 05:54:45'),
(25, 'weirdrafi', 'Rafi@test.com', '$2y$10$HQzLeKFkukYBzHszOsmAK.k2gAfaie7FoZyzl5mdBs8KmQ00ILOHW', '2', '2022-12-29 06:50:08'),
(26, 'ibn', 'ibn1146@gmail.com', '$2y$10$ygOR2k5rYOziT8SNVoUeOuhOjvh8ar8kw6.TZ5/aaIjsp5xUQhXjS', '2', '2022-12-31 06:37:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require "db.php";

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //to get JSON values in PHP you need to use json_decode(file_get_contents('php://input'), true);
    $data = json_decode(file_get_contents('php://input'), true);
    
    $name = $conn->real_escape_string($data['name'] ?? '');
    $description = $conn->real_escape_string($data['description'] ?? '');
    
    if (empty($name)) {
        echo json_encode([
            "success" => false,
            "message" => "Category name is required"
        ]);
        exit;
    }
    
    $sql = "INSERT INTO categories (name, description, created_at) VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $description);
    
    if ($stmt->execute()) {
        $newId = $conn->insert_id;
        echo json_encode([
            "success" => true,
            "message" => "Category added successfully",
            "category" => [
                "id" => $newId,
                "name" => $name,
                "description" => $description
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Error adding category: " . $stmt->error
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        "success" => false,
        "message" => "Only POST method is allowed"
    ]);
}

$conn->close();
?>

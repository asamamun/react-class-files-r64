<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require "db.php";

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$sql = "SELECT * FROM categories ORDER BY id DESC";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categories[] = [
            "id" => $row["id"],
            "name" => $row["name"],
            "description" => $row["description"],
            "created_at" => $row["created_at"]
        ];
    }
}

echo json_encode([
    "success" => true,
    "categories" => $categories
]);

$conn->close();
?>

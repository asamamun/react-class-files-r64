<?php
$conn = new mysqli("localhost","root","","r64_react");
$conn->set_charset("utf8");

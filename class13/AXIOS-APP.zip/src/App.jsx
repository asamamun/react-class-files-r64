import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Categories from './Categories'
import CategoriesAxios from './Categories-axios'
import Products from './Products'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div className="comparison-container">
        <div className="categories-section">
          <Categories />
        </div>
        <div className="categories-section">
          <CategoriesAxios />
        </div>
      </div>
      <Products />
    </>
  )
}

export default App

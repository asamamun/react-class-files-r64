import { useState, useEffect } from 'react';
import axios from 'axios';

function Categories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCategory, setNewCategory] = useState({ name: '', description: '' });
  const [addingCategory, setAddingCategory] = useState(false);

  // Fetch categories
  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost/ROUND64/react/axios-app/APIS/all-categories.php');
      if (response.data.success) {
        setCategories(response.data.categories);
        setError(null);
      } else {
        setError(response.data.message || 'Failed to fetch categories');
      }
    } catch (err) {
      setError('Failed to fetch categories');
      console.error('Error fetching categories:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  // Add new category
  const handleAddCategory = async (e) => {
    e.preventDefault();
    if (!newCategory.name.trim()) {
      alert('Category name is required');
      return;
    }

    try {
      setAddingCategory(true);
      const response = await axios.post('http://localhost/ROUND64/react/axios-app/APIS/add-categories.php', {
        name: newCategory.name,
        description: newCategory.description
      });

      if (response.data.success) {
        setCategories([response.data.category, ...categories]);
        setNewCategory({ name: '', description: '' });
        setShowAddForm(false);
        alert('Category added successfully!');
      } else {
        alert(response.data.message || 'Failed to add category');
      }
    } catch (err) {
      alert('Error adding category');
      console.error('Error adding category:', err);
    } finally {
      setAddingCategory(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCategory(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (loading) {
    return (
      <div className="loading">
        <h2>Loading categories...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error">
        <h2>Error: {error}</h2>
        <button onClick={fetchCategories} className="retry-btn">Retry</button>
      </div>
    );
  }

  return (
    <div className="categories">
      <div className="categories-header">
        <h1>Categories (AXIOS)</h1>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="add-category-btn"
        >
          {showAddForm ? 'Cancel' : 'Add Category'}
        </button>
      </div>

      {showAddForm && (
        <div className="add-category-form">
          <h3>Add New Category</h3>
          <form onSubmit={handleAddCategory}>
            <div className="form-group">
              <label htmlFor="name">Category Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={newCategory.name}
                onChange={handleInputChange}
                placeholder="Enter category name"
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={newCategory.description}
                onChange={handleInputChange}
                placeholder="Enter category description"
                rows="3"
              />
            </div>
            <div className="form-actions">
              <button 
                type="submit" 
                disabled={addingCategory}
                className="submit-btn"
              >
                {addingCategory ? 'Adding...' : 'Add Category'}
              </button>
              <button 
                type="button" 
                onClick={() => setShowAddForm(false)}
                className="cancel-btn"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="categories-grid">
        {categories.length === 0 ? (
          <div className="no-categories">
            <p>No categories found. Add your first category!</p>
          </div>
        ) : (
          categories.map((category) => (
            <div key={category.id} className="category-card">
              <div className="category-info">
                <h3>{category.name}</h3>
                {category.description && (
                  <p className="category-description">{category.description}</p>
                )}
                <p className="category-date">
                  Created: {new Date(category.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Categories;

# React Styling Methods Showcase

This project demonstrates all the different ways to style React components, from inline styles to advanced CSS-in-JS libraries.

## 🎨 Styling Methods Covered

| Method               | Scoped | Dynamic | External Required | Component |
| -------------------- | ------ | ------- | ----------------- | --------- |
| Inline Styles        | Yes    | Yes     | No                | `InlineStyles` |
| CSS Stylesheets      | No     | No      | Yes               | `CssStylesheets` |
| CSS Modules          | Yes    | No      | Yes               | `CssModules` |
| Styled Components    | Yes    | Yes     | Yes               | `StyledComponents` |
| Emotion              | Yes    | Yes     | Yes               | `Emotion` |
| Sass/SCSS            | No     | No      | Yes               | `SassScss` |
| JSS (react-jss)      | Yes    | Yes     | Yes               | `JssComponent` |
| Vanilla Extract      | Yes    | No      | Yes               | `VanillaExtract` |

## 🚀 Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm run dev
   ```

3. **Open your browser and navigate to the local URL shown in the terminal**

## 📦 Dependencies

### Core Dependencies
- `react` - React library
- `react-dom` - React DOM rendering

### Styling Dependencies
- `styled-components` - CSS-in-JS library
- `@emotion/react` & `@emotion/styled` - Emotion CSS-in-JS
- `react-jss` - JSS for React
- `@vanilla-extract/css` - Type-safe CSS-in-JS
- `sass` - Sass/SCSS preprocessor
- `postcss` & `autoprefixer` - CSS processing

## 🎯 Features Demonstrated

Each component showcases:

- **Interactive Counter** - Demonstrates dynamic styling based on state
- **Hover Effects** - Shows interactive styling capabilities
- **Responsive Design** - Adapts to different screen sizes
- **Modern UI** - Beautiful gradients, shadows, and animations
- **Feature List** - Explains the pros/cons of each method

## 📚 Method Details

### 1. Inline Styles
- **Pros:** No external dependencies, dynamic, scoped
- **Cons:** Limited CSS features, verbose syntax
- **Best for:** Simple dynamic styling, prototypes

### 2. CSS Stylesheets
- **Pros:** Familiar syntax, full CSS support
- **Cons:** Global scope, no dynamic styling
- **Best for:** Traditional web development

### 3. CSS Modules
- **Pros:** Scoped styles, familiar CSS syntax
- **Cons:** No dynamic styling, build-time processing
- **Best for:** Component-based styling with CSS

### 4. Styled Components
- **Pros:** Scoped, dynamic, CSS-in-JS
- **Cons:** Runtime overhead, external dependency
- **Best for:** Dynamic styling with component-based approach

### 5. Emotion
- **Pros:** Better performance than styled-components, dynamic
- **Cons:** External dependency, learning curve
- **Best for:** High-performance CSS-in-JS

### 6. Sass/SCSS
- **Pros:** Advanced CSS features, variables, mixins
- **Cons:** Global scope, build-time processing
- **Best for:** Complex styling with advanced CSS features

### 7. JSS (react-jss)
- **Pros:** Scoped, dynamic, JavaScript-based
- **Cons:** External dependency, different syntax
- **Best for:** JavaScript-centric styling

### 8. Vanilla Extract
- **Pros:** Type-safe, zero runtime, scoped
- **Cons:** Build-time only, external dependency
- **Best for:** TypeScript projects requiring type safety

## 🛠️ Build & Deploy

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## 📝 Notes

- All components are interactive with counters and hover effects
- Each method demonstrates its unique capabilities
- The layout is responsive and works on mobile devices
- Color schemes are distinct for each method for easy identification

## 🤝 Contributing

Feel free to add more styling methods or improve existing examples!

## 📄 License

This project is open source and available under the MIT License.

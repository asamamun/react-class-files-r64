import React from 'react';
import './App.css';

// Import all styling components
import InlineStyles from './components/InlineStyles';
import CssStylesheets from './components/CssStylesheets';
import CssModules from './components/CssModules';
import StyledComponents from './components/StyledComponents';
import Emotion from './components/Emotion';
import SassScss from './components/SassScss';
import JssComponent from './components/JssComponent';
import VanillaExtract from './components/VanillaExtract';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>React Styling Methods Showcase</h1>
        <p>Explore different ways to style React components</p>
      </header>
      
      <main className="App-main">
        <div className="components-grid">
          <InlineStyles />
          <CssStylesheets />
          <CssModules />
          <StyledComponents />
          <Emotion />
          <SassScss />
          <JssComponent />
          <VanillaExtract />
        </div>
      </main>
    </div>
  );
}

export default App;

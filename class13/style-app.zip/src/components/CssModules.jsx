import React, { useState } from 'react';
import styles from './CssModules.module.css';
// import styles2 from './CssModules2.module.css';

const CssModules = () => {
  const [count, setCount] = useState(0);

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>CSS Modules Component</h2>
      <p className={styles.description}>
        This component uses CSS modules for scoped styling
      </p>
      
      <div className={styles.counter}>
        Count: {count}
      </div>
      
      <div className={styles.buttonContainer}>
        <button
          className={styles.button}
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          className={`${styles.button} ${styles.buttonSecondary}`}
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div className={styles.features}>
        <strong>Features:</strong>
        <ul>
          <li>Scoped to component</li>
          <li>No dynamic styling</li>
          <li>External CSS file required</li>
          <li>Automatic class name hashing</li>
        </ul>
      </div>
    </div>
  );
};

export default CssModules;

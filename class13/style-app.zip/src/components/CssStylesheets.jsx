import React, { useState } from 'react';
import './CssStylesheets.css';

const CssStylesheets = () => {
  const [count, setCount] = useState(0);

  return (
    <div className="css-stylesheets-container">
      <h2 className="css-stylesheets-title">CSS Stylesheets Component</h2>
      <p className="css-stylesheets-description">
        This component uses traditional CSS stylesheets with class names
      </p>
      
      <div className="css-stylesheets-counter">
        Count: {count}
      </div>
      
      <div className="css-stylesheets-button-container">
        <button
          className="css-stylesheets-button"
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          className="css-stylesheets-button secondary"
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div className="css-stylesheets-features">
        <strong>Features:</strong>
        <ul>
          <li>Not scoped (global styles)</li>
          <li>No dynamic styling</li>
          <li>External CSS file required</li>
          <li>Traditional CSS approach</li>
        </ul>
      </div>
    </div>
  );
};

export default CssStylesheets;

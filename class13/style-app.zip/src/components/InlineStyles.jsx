import React, { useState } from 'react';

const InlineStyles = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [count, setCount] = useState(0);

  // Dynamic styles based on state
  const containerStyle = {
    padding: '20px',
    margin: '10px',
    border: '2px solid #3498db',
    borderRadius: '8px',
    backgroundColor: isHovered ? '#e8f4fd' : '#ffffff',
    transition: 'all 0.3s ease',
    cursor: 'pointer',
    boxShadow: isHovered ? '0 4px 8px rgba(172, 97, 31, 0.94)' : '0 2px 4px rgba(0, 0, 0, 0.1)',
  };

  const titleStyle = {
    color: '#2c3e50',
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
    textAlign: 'center',
  };

  const buttonStyle = {
    backgroundColor: count > 5 ? '#e74c3c' : '#2ecc71',
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
    margin: '5px',
    transition: 'background-color 0.3s ease',
  };

  const counterStyle = {
    fontSize: '18px',
    fontWeight: 'bold',
    color: count > 5 ? '#e74c3c' : '#2c3e50',
    textAlign: 'center',
    margin: '10px 0',
  };

  return (
    <div
      style={containerStyle}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <h2 style={titleStyle}>Inline Styles Component</h2>
      <p style={{ color: '#7f8c8d', textAlign: 'center', marginBottom: '15px' }}>
        This component uses inline styles with dynamic styling based on state
      </p>
      
      <div style={counterStyle}>
        Count: {count}
      </div>
      
      <div style={{ textAlign: 'center' }}>
        <button
          style={buttonStyle}
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          style={{
            ...buttonStyle,
            backgroundColor: '#95a5a6',
          }}
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div style={{
        marginTop: '15px',
        padding: '10px',
        backgroundColor: '#ecf0f1',
        borderRadius: '5px',
        fontSize: '14px',
        color: '#34495e',
      }}>
        <strong>Features:</strong>
        <ul style={{ margin: '5px 0', paddingLeft: '20px' }}>
          <li>Scoped to component</li>
          <li>Dynamic based on state</li>
          <li>No external dependencies</li>
          <li>Real-time style changes</li>
        </ul>
      </div>
    </div>
  );
};

export default InlineStyles;

import React, { useState } from 'react';
import { createUseStyles } from 'react-jss';

const useStyles = createUseStyles({
  container: {
    padding: '20px',
    margin: '10px',
    border: '2px solid #16a085',
    borderRadius: '8px',
    background: 'linear-gradient(135deg, #1abc9c 0%, #16a085 100%)',
    color: 'white',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    transition: 'all 0.3s ease',
    cursor: 'pointer',

    '&:hover': {
      transform: 'translateY(-2px)',
      boxShadow: '0 6px 12px rgba(0, 0, 0, 0.15)',
    },
  },
  title: {
    color: '#ffffff',
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
    textAlign: 'center',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)',
  },
  description: {
    color: '#ecf0f1',
    textAlign: 'center',
    marginBottom: '15px',
    fontSize: '16px',
    lineHeight: 1.5,
  },
  counter: {
    fontSize: '18px',
    fontWeight: 'bold',
    textAlign: 'center',
    margin: '10px 0',
    color: props => props.count > 5 ? '#e74c3c' : '#f1c40f',
    textShadow: '1px 1px 2px rgba(0, 0, 0, 0.5)',
    transition: 'color 0.3s ease',
  },
  button: {
    backgroundColor: '#e74c3c',
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
    margin: '5px',
    transition: 'all 0.3s ease',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',

    '&:hover': {
      backgroundColor: '#c0392b',
      transform: 'scale(1.05)',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
    },

    '&:active': {
      transform: 'scale(0.95)',
    },
  },
  buttonSecondary: {
    backgroundColor: '#95a5a6',

    '&:hover': {
      backgroundColor: '#7f8c8d',
    },
  },
  buttonContainer: {
    textAlign: 'center',
  },
  features: {
    marginTop: '15px',
    padding: '10px',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '5px',
    fontSize: '14px',
    color: '#ecf0f1',
    backdropFilter: 'blur(10px)',

    '& strong': {
      color: '#f1c40f',
    },

    '& ul': {
      margin: '5px 0',
      paddingLeft: '20px',
    },

    '& li': {
      margin: '3px 0',
    },
  },
});

const JssComponent = () => {
  const [count, setCount] = useState(0);
  const classes = useStyles({ count });

  return (
    <div className={classes.container}>
      <h2 className={classes.title}>JSS Component</h2>
      <p className={classes.description}>
        This component uses JSS (react-jss) for dynamic styling
      </p>
      
      <div className={classes.counter}>
        Count: {count}
      </div>
      
      <div className={classes.buttonContainer}>
        <button
          className={classes.button}
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          className={`${classes.button} ${classes.buttonSecondary}`}
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div className={classes.features}>
        <strong>Features:</strong>
        <ul>
          <li>Scoped to component</li>
          <li>Dynamic based on props</li>
          <li>External dependency required</li>
          <li>JavaScript-based styling</li>
        </ul>
      </div>
    </div>
  );
};

export default JssComponent;

import React, { useState } from 'react';
import './SassScss.scss';

const SassScss = () => {
  const [count, setCount] = useState(0);

  return (
    <div className="sass-scss-container">
      <h2 className="title">Sass/SCSS Component</h2>
      <p className="description">
        This component uses Sass/SCSS for advanced styling
      </p>
      
      <div className="counter">
        Count: {count}
      </div>
      
      <div className="button-container">
        <button
          className="button"
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          className="button secondary"
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div className="features">
        <strong>Features:</strong>
        <ul>
          <li>Not scoped (global styles)</li>
          <li>No dynamic styling</li>
          <li>External dependency required</li>
          <li>Advanced CSS preprocessor</li>
        </ul>
      </div>
    </div>
  );
};

export default SassScss;

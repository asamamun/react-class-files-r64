import React, { useState } from 'react';
import styled from 'styled-components';

const Container = styled.div`
  padding: 20px;
  margin: 10px;
  border: 2px solid #27ae60;
  border-radius: 8px;
  background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
  color: white;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  cursor: pointer;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }
`;

const Title = styled.h2`
  color: #ffffff;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 10px;
  text-align: center;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
`;

const Description = styled.p`
  color: #ecf0f1;
  text-align: center;
  margin-bottom: 15px;
  font-size: 16px;
  line-height: 1.5;
`;

const Counter = styled.div`
  font-size: 18px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0;
  color: ${props => props.count > 5 ? '#e74c3c' : '#f1c40f'};
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
  transition: color 0.3s ease;
`;

const Button = styled.button`
  background-color: ${props => props.variant === 'secondary' ? '#95a5a6' : '#e74c3c'};
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  margin: 5px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);

  &:hover {
    background-color: ${props => props.variant === 'secondary' ? '#7f8c8d' : '#c0392b'};
    transform: scale(1.05);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
  }

  &:active {
    transform: scale(0.95);
  }
`;

const ButtonContainer = styled.div`
  text-align: center;
`;

const Features = styled.div`
  margin-top: 15px;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 5px;
  font-size: 14px;
  color: #ecf0f1;
  backdrop-filter: blur(10px);

  strong {
    color: #f1c40f;
  }

  ul {
    margin: 5px 0;
    padding-left: 20px;
  }

  li {
    margin: 3px 0;
  }
`;

const StyledComponents = () => {
  const [count, setCount] = useState(0);

  return (
    <Container>
      <Title>Styled Components</Title>
      <Description>
        This component uses styled-components for dynamic styling
      </Description>
      
      <Counter count={count}>
        Count: {count}
      </Counter>
      
      <ButtonContainer>
        <Button onClick={() => setCount(count + 1)}>
          Increment
        </Button>
        <Button variant="secondary" onClick={() => setCount(0)}>
          Reset
        </Button>
      </ButtonContainer>
      
      <Features>
        <strong>Features:</strong>
        <ul>
          <li>Scoped to component</li>
          <li>Dynamic based on props</li>
          <li>External dependency required</li>
          <li>CSS-in-JS approach</li>
        </ul>
      </Features>
    </Container>
  );
};

export default StyledComponents;

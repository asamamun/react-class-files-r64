import { style } from '@vanilla-extract/css';

export const container = style({
  padding: '20px',
  margin: '10px',
  border: '2px solid #34495e',
  borderRadius: '8px',
  background: 'linear-gradient(135deg, #34495e 0%, #2c3e50 100%)',
  color: 'white',
  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s ease',
  cursor: 'pointer',

  ':hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 6px 12px rgba(0, 0, 0, 0.15)',
  },
});

export const title = style({
  color: '#ffffff',
  fontSize: '24px',
  fontWeight: 'bold',
  marginBottom: '10px',
  textAlign: 'center',
  textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)',
});

export const description = style({
  color: '#ecf0f1',
  textAlign: 'center',
  marginBottom: '15px',
  fontSize: '16px',
  lineHeight: 1.5,
});

export const counter = style({
  fontSize: '18px',
  fontWeight: 'bold',
  textAlign: 'center',
  margin: '10px 0',
  color: '#f1c40f',
  textShadow: '1px 1px 2px rgba(0, 0, 0, 0.5)',
  transition: 'color 0.3s ease',
});

export const button = style({
  backgroundColor: '#e74c3c',
  color: 'white',
  border: 'none',
  padding: '10px 20px',
  borderRadius: '5px',
  cursor: 'pointer',
  fontSize: '16px',
  margin: '5px',
  transition: 'all 0.3s ease',
  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',

  ':hover': {
    backgroundColor: '#c0392b',
    transform: 'scale(1.05)',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
  },

  ':active': {
    transform: 'scale(0.95)',
  },
});

export const buttonSecondary = style({
  backgroundColor: '#95a5a6',

  ':hover': {
    backgroundColor: '#7f8c8d',
  },
});

export const buttonContainer = style({
  textAlign: 'center',
});

export const features = style({
  marginTop: '15px',
  padding: '10px',
  backgroundColor: 'rgba(255, 255, 255, 0.1)',
  borderRadius: '5px',
  fontSize: '14px',
  color: '#ecf0f1',
  backdropFilter: 'blur(10px)',
});

export const featuresStrong = style({
  color: '#f1c40f',
});

export const featuresUl = style({
  margin: '5px 0',
  paddingLeft: '20px',
});

export const featuresLi = style({
  margin: '3px 0',
});

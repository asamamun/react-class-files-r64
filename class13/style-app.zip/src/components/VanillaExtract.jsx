import React, { useState } from 'react';
import * as styles from './VanillaExtract.css';

const VanillaExtract = () => {
  const [count, setCount] = useState(0);

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>Vanilla Extract Component</h2>
      <p className={styles.description}>
        This component uses Vanilla Extract for type-safe styling
      </p>
      
      <div className={styles.counter}>
        Count: {count}
      </div>
      
      <div className={styles.buttonContainer}>
        <button
          className={styles.button}
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
        <button
          className={`${styles.button} ${styles.buttonSecondary}`}
          onClick={() => setCount(0)}
        >
          Reset
        </button>
      </div>
      
      <div className={styles.features}>
        <strong className={styles.featuresStrong}>Features:</strong>
        <ul className={styles.featuresUl}>
          <li className={styles.featuresLi}>Scoped to component</li>
          <li className={styles.featuresLi}>No dynamic styling</li>
          <li className={styles.featuresLi}>External dependency required</li>
          <li className={styles.featuresLi}>Type-safe CSS-in-JS</li>
        </ul>
      </div>
    </div>
  );
};

export default VanillaExtract;

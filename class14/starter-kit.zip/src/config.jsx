// API Configuration
const API_URL = 'http://localhost/ROUND64/react/starter-kit/API/';

export default API_URL;